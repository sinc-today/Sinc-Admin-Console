'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { PagerBar, useClientPager } from '@/components/pager';
import { useState } from 'react';
import { NoAccess } from '@/components/PhasePlaceholder';
import { Button, EmptyState, ErrorState, Field, inputClass, Panel, Skeleton, StatusBadge, Tag } from '@/components/ui';
import { api, ApiError } from '@/lib/api';
import { formatDateTime, formatRelative } from '@/lib/format';
import { useCan, useMe } from '../../me-context';

interface StaffRow {
  id: number;
  userId: number;
  displayName: string;
  email: string;
  status: 'ACTIVE' | 'SUSPENDED';
  role: { key: string; name: string } | null;
  mfaEnabled: boolean;
  lastLoginAt: string | null;
  createdAt: string;
}
interface RoleRow {
  key: string;
  name: string;
  description: string;
  permissions: string[];
}

export default function StaffPage() {
  const canRead = useCan('staff.read');
  const canManage = useCan('staff.manage');
  const staffQ = useQuery({ queryKey: ['staff'], queryFn: () => api<StaffRow[]>('/staff'), enabled: canRead });
  const rolesQ = useQuery({ queryKey: ['roles'], queryFn: () => api<RoleRow[]>('/roles'), enabled: canRead });

  if (!canRead) return <NoAccess />;

  return (
    <div className="flex flex-col gap-5">
      {canManage && rolesQ.data && <AddStaff roles={rolesQ.data} />}

      <Panel title="Staff" freshness={staffQ.data ? `${staffQ.data.length} ${staffQ.data.length === 1 ? 'person' : 'people'} with console access` : undefined}>
        {staffQ.isLoading ? (
          <TableSkeleton />
        ) : staffQ.error ? (
          <ErrorState
            message={staffQ.error.message}
            requestId={(staffQ.error as ApiError).requestId}
            onRetry={() => staffQ.refetch()}
          />
        ) : staffQ.data && staffQ.data.length > 0 ? (
          <StaffTable rows={staffQ.data} roles={rolesQ.data ?? []} canManage={canManage} />
        ) : (
          <EmptyState title="No staff yet" body="The first owner is created when the seed admin signs in. Add teammates from here afterwards." />
        )}
      </Panel>

      <Panel title="Roles" freshness="Defined in code and synced on deploy. Change them in admin/src/rbac/permissions.ts.">
        {rolesQ.isLoading ? (
          <TableSkeleton rows={4} />
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2 2xl:grid-cols-3">
            {rolesQ.data?.map((r) => (
              <div key={r.key} className="rounded-feature bg-fog p-5">
                <p className="display text-[16px] text-ink">{r.name}</p>
                <p className="mt-1 text-[13px] text-ink-secondary">{r.description}</p>
                <p className="mt-3 text-[12px] font-medium text-ink-muted">{r.permissions.length} permissions</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {r.permissions.map((p) => (
                    <Tag key={p}>{p}</Tag>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </Panel>
    </div>
  );
}

function TableSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="flex flex-col gap-3" role="status" aria-label="Loading">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-10 w-full" />
      ))}
    </div>
  );
}

function StaffTable({ rows, roles, canManage }: { rows: StaffRow[]; roles: RoleRow[]; canManage: boolean }) {
  const me = useMe();
  const [editing, setEditing] = useState<number | null>(null);
  const pager = useClientPager(rows);
  return (
    <>
    <div className="relative -mx-6 overflow-x-auto">
      <table className="w-full min-w-[820px] border-collapse text-[13px]">
        <thead>
          <tr className="bg-fog text-left text-[12px] font-medium text-ink-secondary">
            <th scope="col" className="h-10 px-6 font-medium">Name</th>
            <th scope="col" className="px-4 font-medium">Role</th>
            <th scope="col" className="px-4 font-medium">Status</th>
            <th scope="col" className="px-4 font-medium">Two-factor</th>
            <th scope="col" className="px-4 font-medium">Last sign-in</th>
            {canManage && <th scope="col" className="px-6 text-right font-medium"><span className="sr-only">Actions</span></th>}
          </tr>
        </thead>
        <tbody>
          {pager.items.map((s) => (
            <StaffRowView
              key={s.id}
              s={s}
              roles={roles}
              isMe={s.id === me.staff.id}
              canManage={canManage}
              editing={editing === s.id}
              onEdit={() => setEditing(editing === s.id ? null : s.id)}
            />
          ))}
        </tbody>
      </table>
    </div>
    <PagerBar pager={pager} noun="staff" />
    </>
  );
}

function StaffRowView({
  s,
  roles,
  isMe,
  canManage,
  editing,
  onEdit,
}: {
  s: StaffRow;
  roles: RoleRow[];
  isMe: boolean;
  canManage: boolean;
  editing: boolean;
  onEdit: () => void;
}) {
  return (
    <>
      <tr className="h-12 border-b border-line hover:bg-fog">
        <td className="px-6">
          <p className="text-ink">
            {s.displayName} {isMe && <span className="text-ink-muted">(you)</span>}
          </p>
          <p className="text-[12px] text-ink-muted">{s.email}</p>
        </td>
        <td className="px-4 text-ink">{s.role?.name ?? 'None'}</td>
        <td className="px-4">
          {s.status === 'ACTIVE' ? <StatusBadge status="ok">Active</StatusBadge> : <StatusBadge status="warning">Suspended</StatusBadge>}
        </td>
        <td className="px-4">
          {s.mfaEnabled ? <StatusBadge status="ok">On</StatusBadge> : <StatusBadge status="pending">Not set up</StatusBadge>}
        </td>
        <td className="num px-4 text-ink-secondary" title={s.lastLoginAt ? formatDateTime(s.lastLoginAt) : undefined}>
          {s.lastLoginAt ? formatRelative(s.lastLoginAt) : 'Never'}
        </td>
        {canManage && (
          <td className="px-6 text-right">
            {!isMe && (
              <Button variant="quiet" onClick={onEdit} aria-expanded={editing}>
                {editing ? 'Close' : 'Edit'}
              </Button>
            )}
          </td>
        )}
      </tr>
      {editing && (
        <tr className="border-b border-line bg-ivory">
          <td colSpan={6} className="px-6 py-5">
            <EditStaff s={s} roles={roles} onDone={onEdit} />
          </td>
        </tr>
      )}
    </>
  );
}

function EditStaff({ s, roles, onDone }: { s: StaffRow; roles: RoleRow[]; onDone: () => void }) {
  const qc = useQueryClient();
  const [roleKey, setRoleKey] = useState(s.role?.key ?? '');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);

  const mutate = useMutation({
    mutationFn: (body: Record<string, string>) =>
      body.kind === 'mfa'
        ? api(`/staff/${s.id}/reset-mfa`, { method: 'POST', json: { reason } })
        : api(`/staff/${s.id}`, { method: 'PATCH', json: { ...body, reason } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['staff'] });
      onDone();
    },
    onError: (e) => setError(e.message),
  });

  const reasonOk = reason.trim().length >= 3;

  return (
    <div className="flex flex-col gap-4">
      <p className="text-[13px] text-ink-secondary">Changes sign {s.displayName} out of every session. A reason is recorded in the audit log.</p>
      <div className="grid max-w-[880px] grid-cols-1 gap-4 md:grid-cols-[220px_1fr]">
        <Field label="Role" htmlFor={`role-${s.id}`}>
          <select id={`role-${s.id}`} value={roleKey} onChange={(e) => setRoleKey(e.target.value)} className={inputClass}>
            {roles.map((r) => (
              <option key={r.key} value={r.key}>
                {r.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Reason" htmlFor={`reason-${s.id}`} error={error ?? undefined} helper="For example: moved to the finance team">
          <input id={`reason-${s.id}`} value={reason} onChange={(e) => setReason(e.target.value)} className={inputClass} />
        </Field>
      </div>
      <div className="flex flex-wrap gap-3">
        <Button disabled={!reasonOk || roleKey === s.role?.key} loading={mutate.isPending} onClick={() => mutate.mutate({ roleKey })}>
          Change role
        </Button>
        <Button
          variant="secondary"
          disabled={!reasonOk}
          onClick={() => mutate.mutate({ status: s.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE' })}
        >
          {s.status === 'ACTIVE' ? 'Suspend access' : 'Restore access'}
        </Button>
        {s.mfaEnabled && (
          <Button variant="secondary" disabled={!reasonOk} onClick={() => mutate.mutate({ kind: 'mfa' })}>
            Reset two-factor
          </Button>
        )}
      </div>
    </div>
  );
}

function AddStaff({ roles }: { roles: RoleRow[] }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [roleKey, setRoleKey] = useState('viewer');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);

  const add = useMutation({
    mutationFn: () => api('/staff', { method: 'POST', json: { email, roleKey, reason } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['staff'] });
      setEmail('');
      setReason('');
      setOpen(false);
    },
    onError: (e) => setError(e.message),
  });

  if (!open) {
    return (
      <div>
        <Button onClick={() => setOpen(true)}>Add staff member</Button>
      </div>
    );
  }

  return (
    <Panel title="Add staff member">
      <form
        className="flex max-w-[880px] flex-col gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          setError(null);
          add.mutate();
        }}
      >
        <p className="text-[13px] text-ink-secondary">
          The person needs a Sinc account with the ADMIN access role. They set up two-factor authentication the first time they sign in.
        </p>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <Field label="Email" htmlFor="add-email">
            <input id="add-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={inputClass} />
          </Field>
          <Field label="Role" htmlFor="add-role">
            <select id="add-role" value={roleKey} onChange={(e) => setRoleKey(e.target.value)} className={inputClass}>
              {roles.map((r) => (
                <option key={r.key} value={r.key}>
                  {r.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Reason" htmlFor="add-reason" helper="Recorded in the audit log">
            <input id="add-reason" required value={reason} onChange={(e) => setReason(e.target.value)} className={inputClass} />
          </Field>
        </div>
        {error && <p className="text-[12px] text-ember-ink">{error}</p>}
        <div className="flex gap-3">
          <Button type="submit" loading={add.isPending} disabled={!email || reason.trim().length < 3}>
            Add staff member
          </Button>
          <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
        </div>
      </form>
    </Panel>
  );
}
