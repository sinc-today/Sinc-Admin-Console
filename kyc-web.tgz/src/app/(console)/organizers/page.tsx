'use client';

import { parseAsString, useQueryStates } from 'nuqs';
import { NoAccess } from '@/components/PhasePlaceholder';
import { fmt } from '@/components/analytics-ui';
import { ExportButton, ListState, verificationBadge, RowLink, SavedViews, SearchForm, SelectField, Table, dayFmt, td, tdFirst, tdLast } from '@/components/directory-ui';
import { PagerBar, useCursorPager } from '@/components/pager';
import { Button, Panel } from '@/components/ui';
import { useScopeParams } from '@/lib/analytics';
import { useCan } from '../me-context';

interface OrgRow {
  id: number;
  name: string;
  username: string | null;
  owner: { id: number; name: string | null } | null;
  verification: string | null;
  kycApproved: boolean;
  isActive: boolean;
  country: string | null;
  createdAt: string;
  events: number;
  upcoming: number;
  gmv: number;
  payments: number;
}

export default function OrganizersPage() {
  const can = useCan('organizers.read');
  const canExport = useCan('analytics.read');
  const { params: scope, currency } = useScopeParams();
  const [f, setF] = useQueryStates({ q: parseAsString, verification: parseAsString, kyc: parseAsString, orgCountry: parseAsString });
  const params = new URLSearchParams(scope);
  Object.entries(f).forEach(([k, v]) => v && params.set(k, v));
  const q = useCursorPager<OrgRow>('/organizers', params, { enabled: can });
  if (!can) return <NoAccess />;
  const items = q.items;
  const exportParams = new URLSearchParams(params);
  exportParams.delete('limit');
  return (
    <div className="flex flex-col gap-5">
      <Panel
        title="Find organizers"
        actions={
          <>
            <SavedViews page="organizers" />
            {canExport && <ExportButton path="/exports/organizers.csv" params={exportParams} />}
          </>
        }
      >
        <SearchForm id="o-q" label="Organizer id, name or handle" initial={f.q ?? ''} onSearch={(v) => setF({ q: v })} />
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-3">
          <SelectField id="o-v" label="Verification" value={f.verification} onChange={(v) => setF({ verification: v })} options={[{ value: 'APPROVED', label: 'Approved' }, { value: 'PENDING', label: 'Pending' }, { value: 'DECLINED', label: 'Declined' }]} />
          <SelectField id="o-k" label="KYC" value={f.kyc} onChange={(v) => setF({ kyc: v })} options={[{ value: 'true', label: 'Approved' }, { value: 'false', label: 'Not approved' }]} />
          <SelectField id="o-c" label="Registered in" value={f.orgCountry} onChange={(v) => setF({ orgCountry: v })} options={[{ value: 'RWA', label: 'Rwanda' }, { value: 'UGA', label: 'Uganda' }]} />
        </div>
      </Panel>
      <Panel title="Organizers" freshness={`Newest first. GMV is ${currency} in the selected date range.`}>
        <ListState q={q} count={items.length} emptyTitle="No organizers match" emptyBody="Clear a filter or try another name.">
          <Table head={['Id', 'Organizer', 'Owner', 'Verification', 'KYC', 'Country', 'Events', { label: `GMV (${currency})`, align: 'right' }, 'Joined']} minWidth={1040}>
            {items.map((o) => (
              <tr key={o.id} className="h-11 border-b border-line hover:bg-fog">
                <td className={`num ${tdFirst}`}>
                  <RowLink href={`/organizers/${o.id}`}>{o.id}</RowLink>
                </td>
                <td className={`${td} max-w-[240px] truncate text-ink`}>
                  {o.name}
                  {o.username && <span className="ml-1.5 text-[12px] text-ink-muted">@{o.username}</span>}
                </td>
                <td className={`${td} max-w-[160px] truncate`}>{o.owner ? <RowLink href={`/users/${o.owner.id}`}>{o.owner.name ?? `#${o.owner.id}`}</RowLink> : 'None'}</td>
                <td className={td}>{verificationBadge(o.verification)}</td>
                <td className={`${td} text-ink-secondary`}>{o.kycApproved ? 'Approved' : 'No'}</td>
                <td className={`${td} text-ink-secondary`}>{o.country === 'UGA' ? 'Uganda' : o.country === 'RWA' ? 'Rwanda' : 'Unknown'}</td>
                <td className={`num ${td} text-ink-secondary`}>
                  {o.events}
                  {o.upcoming > 0 && <span className="ml-1 text-[12px] text-ink-muted">({o.upcoming} upcoming)</span>}
                </td>
                <td className={`num ${td} text-right text-ink`}>{o.gmv ? fmt('money', o.gmv, currency).replace(/^(RWF|UGX)\s/, '') : '0'}</td>
                <td className={`num ${tdLast} whitespace-nowrap text-ink-secondary`}>{dayFmt(o.createdAt)}</td>
              </tr>
            ))}
          </Table>
        </ListState>
        <PagerBar pager={q} noun="organizers" />
      </Panel>
    </div>
  );
}
