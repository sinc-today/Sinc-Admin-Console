'use client';

import { useQuery } from '@tanstack/react-query';
import { parseAsInteger, parseAsString, useQueryStates } from 'nuqs';
import { NoAccess } from '@/components/PhasePlaceholder';
import { fmt, humanize } from '@/components/analytics-ui';
import { Table, td, tdFirst, tdLast } from '@/components/directory-ui';
import { ErrorState, Panel, Skeleton, StatusBadge } from '@/components/ui';
import { api, ApiError } from '@/lib/api';
import { formatRelative } from '@/lib/format';
import { useCan } from '../me-context';

type Health = 'operational' | 'degraded' | 'down';
const BADGE: Record<Health, [React.ComponentProps<typeof StatusBadge>['status'], string]> = {
  operational: ['ok', 'Operational'],
  degraded: ['warning', 'Degraded'],
  down: ['critical', 'Down'],
};
const Status = ({ s }: { s: Health }) => <StatusBadge status={BADGE[s][0]}>{BADGE[s][1]}</StatusBadge>;
const ms = (v: number | null) => (v === null ? '–' : v >= 10000 ? '> 10 s' : v >= 1000 ? `${(v / 1000).toFixed(1)} s` : `${Math.round(v)} ms`);
const WINDOWS = [15, 60, 360, 1440];
const windowLabel = (m: number) => (m < 60 ? `${m} min` : m === 60 ? '1 hour' : m === 1440 ? '24 hours' : `${m / 60} hours`);

function useHealth<T>(path: string, key: unknown[], refetchMs = 30_000) {
  return useQuery({ queryKey: ['health', path, ...key], queryFn: () => api<T>(path), refetchInterval: refetchMs });
}

function Section<T>({ title, freshness, q, children }: { title: string; freshness?: string; q: { isLoading: boolean; error: unknown; data?: T; refetch: () => unknown }; children: (d: T) => React.ReactNode }) {
  return (
    <Panel title={title} freshness={freshness}>
      {q.isLoading ? <Skeleton className="h-32 w-full" /> : q.error ? <ErrorState message={(q.error as Error).message} requestId={(q.error as ApiError).requestId} onRetry={() => q.refetch()} /> : q.data ? children(q.data) : null}
    </Panel>
  );
}

interface Svc {
  key: string;
  label: string;
  status: Health;
  reachable: boolean;
  probeError: string | null;
  requests: number;
  perMinute: number;
  errorRate: number | null;
  p50: number | null;
  p95: number | null;
  p99: number | null;
  lastRequestAt: string | null;
}

export default function HealthPage() {
  const can = useCan('health.read');
  const [s, setS] = useQueryStates({ minutes: parseAsInteger.withDefault(60), service: parseAsString });
  const svc = useHealth<{ services: Svc[] }>(`/health/services?minutes=${s.minutes}`, [s.minutes]);
  const routes = useHealth<{ items: { service: string; method: string; route: string; requests: number; errorRate: number | null; clientErrorRate: number | null; p95: number | null; avgMs: number | null }[] }>(
    `/health/routes?minutes=${s.minutes}${s.service ? `&service=${s.service}` : ''}`,
    [s.minutes, s.service]
  );
  const providers = useHealth<{
    payments: { gateway: string; attempts: number; succeeded: number; failed: number; pending: number; successRate: number | null; p95Seconds: number | null; lastSuccessAt: string | null; status: Health }[];
    sms: { gateway: string; sent: number; failed: number; failRate: number | null; lastAt: string | null }[];
  }>('/health/providers', [], 60_000);
  const dbs = useHealth<{ items: { label: string; configured: boolean; ok?: boolean; error?: string; pingMs?: number; size?: string; connections?: number; active?: number; longest?: number | null; max?: number; slow?: { query: string; calls: number; mean_ms: number }[] }[] }>('/health/databases', [], 60_000);
  const jobs = useHealth<{
    items: { job: string; schedule: string; runs24h: number; failed24h: number; lastStartedAt: string; lastStatus: string; lastError: string | null; avgSeconds: number | null; status: Health }[];
    partnerCredits: { waiting: number; failed: number; oldestWaitingAt: string | null; status: Health };
  }>('/health/jobs', [], 60_000);
  const rabbit = useHealth<{ configured: boolean; items: { name: string; depth: number; unacked: number; consumers: number; publishRate: number; deliverRate: number; status: Health }[] }>('/health/queues', [], 30_000);
  if (!can) return <NoAccess />;

  return (
    <div className="flex flex-col gap-5">
      <Alerts />
      <div role="group" aria-label="Time window" className="flex flex-wrap items-center gap-1">
        <span className="mr-2 text-[13px] text-ink-secondary">Window</span>
        {WINDOWS.map((m) => (
          <button key={m} type="button" aria-pressed={s.minutes === m} onClick={() => setS({ minutes: m === 60 ? null : m })} className={s.minutes === m ? 'h-8 rounded-tag bg-ink px-3 text-[13px] text-canvas' : 'h-8 rounded-tag bg-canvas px-3 text-[13px] text-ink hover:bg-fog'}>
            {windowLabel(m)}
          </button>
        ))}
      </div>

      <Section title="Services" freshness={`Requests seen by the metrics middleware over the last ${windowLabel(s.minutes)}; reachability checked now. Refreshes every 30 seconds.`} q={svc}>
        {(d) => (
          <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {d.services.map((x) => (
              <li key={x.key} className="flex flex-col gap-2 bg-fog p-4">
                <div className="flex items-center justify-between gap-2">
                  <button type="button" className="display text-[18px] text-ink underline-offset-4 hover:underline" onClick={() => setS({ service: x.key === 'admin' ? null : x.key })} aria-label={`Show ${x.label} routes`}>
                    {x.label}
                  </button>
                  <Status s={x.status} />
                </div>
                {!x.reachable && <p className="text-[12px] text-ember-ink">Not reachable ({x.probeError})</p>}
                <dl className="num grid grid-cols-2 gap-x-3 gap-y-1 text-[12px]">
                  <dt className="text-ink-secondary">Requests/min</dt>
                  <dd className="text-right text-ink">{x.key === 'admin' ? '–' : x.perMinute.toFixed(1)}</dd>
                  <dt className="text-ink-secondary">5xx errors</dt>
                  <dd className="text-right text-ink">{fmt('ratio', x.errorRate)}</dd>
                  <dt className="text-ink-secondary">p50 / p95</dt>
                  <dd className="text-right text-ink">
                    {ms(x.p50)} / {ms(x.p95)}
                  </dd>
                  <dt className="text-ink-secondary">Last request</dt>
                  <dd className="text-right text-ink">{x.lastRequestAt ? formatRelative(x.lastRequestAt) : 'Never'}</dd>
                </dl>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title={`Routes${s.service ? `: ${humanize(s.service)}` : ''}`} freshness="Worst error rate first. Latency is the upper bound of the histogram bucket." q={routes}>
        {(d) => (
          <>
            {s.service && (
              <button type="button" className="mb-3 text-[13px] underline underline-offset-4" onClick={() => setS({ service: null })}>
                Show all services
              </button>
            )}
            {!d.items.length ? (
              <p className="py-6 text-[13px] text-ink-muted">No requests recorded in this window. Check that each service has ADMIN_INGEST_URL set.</p>
            ) : (
              <Table minWidth={820} head={['Service', 'Route', { label: 'Requests', align: 'right' }, { label: '5xx', align: 'right' }, { label: '4xx', align: 'right' }, { label: 'Average', align: 'right' }, { label: 'p95', align: 'right' }]}>
                {d.items.slice(0, 50).map((r) => (
                  <tr key={`${r.service}${r.method}${r.route}`} className="h-10 border-b border-line">
                    <td className={`${tdFirst} text-ink-secondary`}>{humanize(r.service)}</td>
                    <td className={`${td} max-w-[420px] truncate font-mono text-[12px]`} title={`${r.method} ${r.route}`}>
                      {r.method} {r.route}
                    </td>
                    <td className={`num ${td} text-right`}>{fmt('count', r.requests)}</td>
                    <td className={`num ${td} text-right ${r.errorRate && r.errorRate > 0.05 ? 'text-ember-ink' : ''}`}>{fmt('ratio', r.errorRate)}</td>
                    <td className={`num ${td} text-right`}>{fmt('ratio', r.clientErrorRate)}</td>
                    <td className={`num ${td} text-right`}>{ms(r.avgMs)}</td>
                    <td className={`num ${tdLast} text-right`}>{ms(r.p95)}</td>
                  </tr>
                ))}
              </Table>
            )}
          </>
        )}
      </Section>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <Section title="Payment providers" freshness="Last hour. Degraded when no successful payment in 30 minutes or success below 80%." q={providers}>
          {(d) =>
            !d.payments.length ? (
              <p className="py-6 text-[13px] text-ink-muted">No provider payments in the last hour.</p>
            ) : (
              <Table minWidth={560} head={['Provider', 'Status', { label: 'Attempts', align: 'right' }, { label: 'Success', align: 'right' }, { label: 'p95', align: 'right' }, 'Last success']}>
                {d.payments.map((p) => (
                  <tr key={p.gateway} className="h-10 border-b border-line">
                    <td className={tdFirst}>{humanize(p.gateway)}</td>
                    <td className={td}>
                      <Status s={p.status} />
                    </td>
                    <td className={`num ${td} text-right`}>{fmt('count', p.attempts)}</td>
                    <td className={`num ${td} text-right`}>{fmt('ratio', p.successRate)}</td>
                    <td className={`num ${td} text-right`}>{p.p95Seconds === null ? '–' : `${Math.round(p.p95Seconds)} s`}</td>
                    <td className={`${tdLast} text-ink-secondary`}>{p.lastSuccessAt ? formatRelative(p.lastSuccessAt) : 'None'}</td>
                  </tr>
                ))}
              </Table>
            )
          }
        </Section>
        <Section title="SMS gateways" freshness="Last 24 hours." q={providers}>
          {(d) =>
            !d.sms.length ? (
              <p className="py-6 text-[13px] text-ink-muted">No SMS in the last 24 hours.</p>
            ) : (
              <Table minWidth={460} head={['Gateway', { label: 'Sent', align: 'right' }, { label: 'Failed', align: 'right' }, 'Last sent']}>
                {d.sms.map((x) => (
                  <tr key={x.gateway} className="h-10 border-b border-line">
                    <td className={tdFirst}>{humanize(x.gateway)}</td>
                    <td className={`num ${td} text-right`}>{fmt('count', x.sent)}</td>
                    <td className={`num ${td} text-right ${x.failRate && x.failRate > 0.1 ? 'text-ember-ink' : ''}`}>
                      {fmt('count', x.failed)} ({fmt('ratio', x.failRate)})
                    </td>
                    <td className={`${tdLast} text-ink-secondary`}>{x.lastAt ? formatRelative(x.lastAt) : '–'}</td>
                  </tr>
                ))}
              </Table>
            )
          }
        </Section>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <Section title="Databases" freshness="Read from each database's own statistics. Slow queries need pg_stat_statements." q={dbs}>
          {(d) => (
            <ul className="flex flex-col gap-3">
              {d.items.map((x) => (
                <li key={x.label} className="bg-fog p-3 text-[13px]">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-ink">{x.label}</span>
                    {!x.configured ? <span className="text-ink-muted">Not configured</span> : x.ok ? <Status s={(x.connections ?? 0) > (x.max ?? 100) * 0.8 ? 'degraded' : 'operational'} /> : <Status s="down" />}
                  </div>
                  {x.ok && (
                    <p className="num mt-1 text-[12px] text-ink-secondary">
                      {x.size} · {x.connections}/{x.max} connections ({x.active} active) · ping {x.pingMs} ms{x.longest ? ` · longest query ${x.longest} s` : ''}
                    </p>
                  )}
                  {x.error && <p className="mt-1 text-[12px] text-ember-ink">{x.error}</p>}
                  {!!x.slow?.length && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-[12px]">Slowest queries</summary>
                      <ul className="mt-1 flex flex-col gap-1 font-mono text-[11px] text-ink-secondary">
                        {x.slow.map((q, i) => (
                          <li key={i} className="truncate" title={q.query}>
                            {q.mean_ms} ms × {q.calls}: {q.query}
                          </li>
                        ))}
                      </ul>
                    </details>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Section>
        <Section title="Scheduled jobs" freshness="The console's own jobs over the last 24 hours." q={jobs}>
          {(d) => (
            <>
              <Table minWidth={520} head={['Job', 'Status', { label: 'Runs', align: 'right' }, { label: 'Failed', align: 'right' }, 'Last run']}>
                {d.items.map((j) => (
                  <tr key={j.job} className="h-10 border-b border-line" title={j.lastError ?? undefined}>
                    <td className={tdFirst}>{humanize(j.job)}</td>
                    <td className={td}>
                      <Status s={j.status} />
                    </td>
                    <td className={`num ${td} text-right`}>{fmt('count', j.runs24h)}</td>
                    <td className={`num ${td} text-right`}>{fmt('count', j.failed24h)}</td>
                    <td className={`${tdLast} text-ink-secondary`}>{formatRelative(j.lastStartedAt)}</td>
                  </tr>
                ))}
              </Table>
              <p className="mt-3 flex items-center gap-2 text-[13px]">
                Partner credits: <Status s={d.partnerCredits.status} /> {fmt('count', d.partnerCredits.waiting)} waiting, {fmt('count', d.partnerCredits.failed)} failed
                {d.partnerCredits.oldestWaitingAt && `, oldest ${formatRelative(d.partnerCredits.oldestWaitingAt)}`}
              </p>
            </>
          )}
        </Section>
      </div>

      <Section title="RabbitMQ" freshness="Queues from the RabbitMQ management API." q={rabbit}>
        {(d) =>
          !d.configured ? (
            <p className="py-4 text-[13px] text-ink-muted">Not connected. Add RABBITMQ_USER and RABBITMQ_PASSWORD (the same as the other services) to the admin service to see queue depth and consumers.</p>
          ) : (
            <Table minWidth={620} head={['Queue', 'Status', { label: 'Depth', align: 'right' }, { label: 'Unacked', align: 'right' }, { label: 'Consumers', align: 'right' }, { label: 'In/s', align: 'right' }, { label: 'Out/s', align: 'right' }]}>
              {d.items.map((x) => (
                <tr key={x.name} className="h-10 border-b border-line">
                  <td className={`${tdFirst} font-mono text-[12px]`}>{x.name}</td>
                  <td className={td}>
                    <Status s={x.status} />
                  </td>
                  <td className={`num ${td} text-right`}>{fmt('count', x.depth)}</td>
                  <td className={`num ${td} text-right`}>{fmt('count', x.unacked)}</td>
                  <td className={`num ${td} text-right`}>{x.consumers}</td>
                  <td className={`num ${td} text-right`}>{x.publishRate.toFixed(1)}</td>
                  <td className={`num ${tdLast} text-right`}>{x.deliverRate.toFixed(1)}</td>
                </tr>
              ))}
            </Table>
          )
        }
      </Section>
    </div>
  );
}

function Alerts() {
  const q = useHealth<{ notifying: { slack: boolean; webhook: boolean }; items: { key: string; firing: boolean; title: string; detail: string | null; severity: 'critical' | 'warning'; since: string; resolvedAt: string | null }[] }>('/health/alerts', [], 60_000);
  const firing = q.data?.items.filter((a) => a.firing) ?? [];
  const resolved = q.data?.items.filter((a) => !a.firing).slice(0, 5) ?? [];
  if (q.isLoading || q.error || !q.data) return null;
  const where = [q.data.notifying.slack && 'Slack', q.data.notifying.webhook && 'the alert webhook'].filter(Boolean).join(' and ');
  return (
    <section aria-label="Alerts" className={firing.length ? 'rounded-panel bg-ember-wash p-5' : 'rounded-panel bg-canvas p-5'}>
      <h2 className="display text-[16px] text-ink">{firing.length ? `${firing.length} ${firing.length === 1 ? 'alert' : 'alerts'} now` : 'No alerts'}</h2>
      <p className="mt-1 text-[12px] text-ink-secondary">Checked every 5 minutes. {where ? `Sent to ${where}.` : 'Not sent anywhere yet: set ALERT_SLACK_WEBHOOK_URL or ALERT_WEBHOOK_URL in the admin service.'}</p>
      {!!firing.length && (
        <ul className="mt-3 flex flex-col gap-2">
          {firing.map((a) => (
            <li key={a.key} className="flex flex-wrap items-start gap-2 text-[13px]">
              <StatusBadge status={a.severity === 'critical' ? 'critical' : 'warning'}>{a.severity === 'critical' ? 'Critical' : 'Warning'}</StatusBadge>
              <span className="text-ink">{a.title}</span>
              {a.detail && <span className="text-ink-secondary">{a.detail}</span>}
              <span className="text-ink-muted">since {formatRelative(a.since)}</span>
            </li>
          ))}
        </ul>
      )}
      {!!resolved.length && (
        <details className="mt-3 text-[12px] text-ink-secondary">
          <summary className="cursor-pointer">Recently resolved</summary>
          <ul className="mt-1 flex flex-col gap-1">
            {resolved.map((a) => (
              <li key={a.key}>
                {a.title}, resolved {a.resolvedAt ? formatRelative(a.resolvedAt) : ''}
              </li>
            ))}
          </ul>
        </details>
      )}
    </section>
  );
}
