'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useState } from 'react';
import { NoAccess } from '@/components/PhasePlaceholder';
import { fmt, humanize } from '@/components/analytics-ui';
import { BigNumber, ExportButton, Table, td, tdFirst, tdLast } from '@/components/directory-ui';
import { PagerBar, useCursorPager, useOffsetPager } from '@/components/pager';
import { useScopeParams } from '@/lib/analytics';
import { Button, ErrorState, Field, inputClass, Panel, Skeleton, StatusBadge } from '@/components/ui';
import { api, ApiError } from '@/lib/api';
import { useCan } from '../../me-context';
import { Account, COUNTRY_NAME, Credits, SplitPreview, Terms, TermsFields, Totals, accountLabel, emptyTerms, kigaliToday, pct, termsPayload } from '../shared';

interface Detail {
  id: number;
  name: string;
  legalName: string | null;
  countries: string[];
  status: 'active' | 'suspended';
  contactEmail: string | null;
  note: string | null;
  account: Account | null;
  terms: Terms[];
  allTime: Totals[];
  operatorCredits: Credits;
  blockerCredits: Credits;
}

export default function PartnerPage() {
  const can = useCan('partners.read');
  const canManage = useCan('partners.manage');
  const { id } = useParams<{ id: string }>();
  const q = useQuery({ queryKey: ['partner', id], queryFn: () => api<Detail>(`/partners/${id}`), enabled: can });
  if (!can) return <NoAccess />;
  if (q.isLoading) return <Skeleton className="h-[480px] w-full" />;
  if (q.error) return <ErrorState message={(q.error as Error).message} requestId={(q.error as ApiError).requestId} onRetry={() => q.refetch()} />;
  const p = q.data!;
  const all = p.allTime[0];
  const cur = all?.currency ?? (p.countries[0] === 'UGA' ? 'UGX' : 'RWF');
  const c = p.operatorCredits;
  const current = p.terms.find((t) => t.state === 'in_force');
  return (
    <div className="flex flex-col gap-5">
      <nav aria-label="Breadcrumb" className="text-[13px] text-ink-secondary">
        <Link href="/partners" className="hover:underline">
          Partners
        </Link>{' '}
        / <span className="text-ink">{p.name}</span>
      </nav>
      <Panel>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <h2 className="display text-[32px] leading-tight text-ink">{p.name}</h2>
            <p className="mt-1 text-[13px] text-ink-secondary">
              {p.legalName && `${p.legalName} · `}
              {p.countries.map((x) => COUNTRY_NAME[x] ?? x).join(', ')} · pays into {accountLabel(p.account)}
              {p.contactEmail && ` · ${p.contactEmail}`}
            </p>
          </div>
          {p.status === 'suspended' ? <StatusBadge status="warning">Suspended: no new shares</StatusBadge> : <StatusBadge status="ok">Active</StatusBadge>}
        </div>
      </Panel>

      <section aria-label="All-time figures" className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <BigNumber label="Operator share, all time" value={fmt('money', all?.operatorShare ?? 0, cur, true)} sub={`${fmt('count', all?.sales ?? 0)} sales, ${fmt('money', all?.gross ?? 0, cur, true)} in tickets`} />
        <BigNumber label="Credited to their account" value={fmt('money', c.credited.amount, cur, true)} sub={`${fmt('count', c.credited.count)} ${c.credited.count === 1 ? 'credit' : 'credits'}`} />
        <BigNumber
          label="Not credited yet"
          value={fmt('money', c.inFlight.amount + c.held.amount + c.failed.amount, cur, true)}
          sub={
            c.failed.count ? `${fmt('count', c.failed.count)} failed: see below` : c.held.count ? `${fmt('count', c.held.count)} waiting for an account` : c.inFlight.count ? 'Being credited now' : 'Nothing waiting'
          }
        />
        <BigNumber label="Sinc keeps, all time" value={fmt('money', all?.sincKeep ?? 0, cur, true)} sub={`Royalty ${fmt('money', all?.royalty ?? 0, cur, true)}${all?.blocker ? ` · blocker ${fmt('money', all.blocker, cur, true)}` : ''}`} />
      </section>

      {canManage && c.failed.count > 0 && <RetryFailed id={p.id} count={c.failed.count} />}
      {p.blockerCredits.held.count > 0 && (
        <p role="status" className="bg-canvas p-4 text-[13px] text-ink">
          {fmt('money', p.blockerCredits.held.amount, cur)} of blocker shares ({fmt('count', p.blockerCredits.held.count)} sales) are waiting for the blocker&apos;s Sinc account. Schedule terms that set the account and they are paid into it.
        </p>
      )}

      <TermsPanel p={p} canManage={canManage} />
      {current && <SplitPreview id="pp-preview" country={p.countries[0] ?? 'UGA'} terms={{ royaltyPct: String(current.royaltyPct), blockerPct: String(current.blockerPct), blockerSincPct: String(current.blockerSincPct) }} />}
      <ByEvent id={p.id} />
      <Statement id={p.id} />
      <Sales id={p.id} />
      <PortalAccess id={p.id} canManage={canManage} />
      {canManage && <EditPartner p={p} />}
    </div>
  );
}

/* ------------------------------------------------------------------ terms */
function TermsPanel({ p, canManage }: { p: Detail; canManage: boolean }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const last = p.terms[0];
  const nextDay = last ? new Date(Math.max(Date.parse(`${last.effectiveFrom}T00:00:00Z`) + 86_400_000, Date.parse(`${kigaliToday()}T00:00:00Z`))).toISOString().slice(0, 10) : kigaliToday();
  const [draft, setDraft] = useState(() => ({ ...emptyTerms(nextDay), ...(last ? { royaltyPct: String(last.royaltyPct), blockerPct: String(last.blockerPct), blockerSincPct: String(last.blockerSincPct), blockerLabel: last.blockerLabel ?? '', blockerPayoutOrganizerProfileId: last.blockerPayoutOrganizerProfileId ? String(last.blockerPayoutOrganizerProfileId) : '' } : {}) }));
  const [reason, setReason] = useState('');
  const save = useMutation({
    mutationFn: () => api(`/partners/${p.id}/terms`, { method: 'POST', json: { ...termsPayload(draft), reason } }),
    onSuccess: () => {
      setOpen(false);
      setReason('');
      qc.invalidateQueries({ queryKey: ['partner', String(p.id)] });
    },
  });
  return (
    <Panel title="Agreement terms" freshness="All percentages are points of the ticket price. Commission minus the aggregator fee is shared: Sinc's royalty and any blocker come off, the rest is the operator's.">
      <Table minWidth={760} head={['Version', 'From', 'Sinc royalty', 'Blocker', 'Status', 'Note']}>
        {p.terms.map((t) => (
          <tr key={t.id} className="h-12 border-b border-line">
            <td className={`num ${tdFirst}`}>v{t.version}</td>
            <td className={`num ${td} whitespace-nowrap text-ink-secondary`}>
              {t.effectiveFrom}
              {t.effectiveTo && <span className="text-ink-muted"> to {t.effectiveTo}</span>}
            </td>
            <td className={`num ${td}`}>{pct(t.royaltyPct)}</td>
            <td className={`${td} text-[13px]`}>
              {t.blockerPct > 0 ? (
                <>
                  {t.blockerLabel || 'Blocker'} {pct(t.blockerPct)}
                  <div className="text-[12px] text-ink-muted">
                    Sinc funds {pct(t.blockerSincPct)} · pays into {accountLabel(t.blockerAccount)}
                  </div>
                </>
              ) : (
                <span className="text-ink-muted">None</span>
              )}
            </td>
            <td className={td}>{t.state === 'in_force' ? <StatusBadge status="ok">In force</StatusBadge> : t.state === 'scheduled' ? <StatusBadge status="pending">Scheduled</StatusBadge> : <StatusBadge status="info">Ended</StatusBadge>}</td>
            <td className={`${tdLast} max-w-[220px] truncate text-[12px] text-ink-muted`} title={t.note ?? undefined}>
              {t.note}
            </td>
          </tr>
        ))}
      </Table>
      {canManage &&
        (open ? (
          <form
            className="mt-5 flex flex-col gap-4 bg-fog p-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate();
            }}
          >
            <p className="text-[13px] text-ink-secondary">Schedule the next step, for example the royalty that applies when a grace period ends. The current terms end the day the new ones start.</p>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <TermsFields id="nt" value={draft} onChange={setDraft} />
            </div>
            <SplitPreview id="nt-preview" country={p.countries[0] ?? 'UGA'} terms={draft} />
            <Field label="Reason (recorded in the audit log)" htmlFor="nt-reason">
              <input id="nt-reason" required minLength={5} className={inputClass} value={reason} onChange={(e) => setReason(e.target.value)} />
            </Field>
            {save.error && <p className="text-[12px] text-ember-ink">{(save.error as Error).message}</p>}
            <div className="flex gap-2">
              <Button type="submit" loading={save.isPending}>
                Save terms
              </Button>
              <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
                Cancel
              </Button>
            </div>
          </form>
        ) : (
          <div className="mt-4">
            <Button variant="secondary" onClick={() => setOpen(true)}>
              Schedule new terms
            </Button>
          </div>
        ))}
    </Panel>
  );
}

/* ------------------------------------------------------------------ statement */
interface StatementData {
  month: string;
  byCurrency: {
    currency: string;
    totals: { sales: number; gross: number; commission: number; aggregatorFee: number; royalty: number; blocker: number; operatorShare: number; sincKeep: number };
    byGateway: { gateway: string; sales: number; gross: number; commission: number; aggregatorFee: number; royalty: number; blocker: number; operatorShare: number; sincKeep: number }[];
  }[];
  operatorCredited: { amount: number; count: number };
}

const thisMonth = () => kigaliToday().slice(0, 7);

function Statement({ id }: { id: number }) {
  const canExport = useCan('exports.finance');
  const [month, setMonth] = useState(thisMonth());
  const q = useQuery({ queryKey: ['partner-statement', id, month], queryFn: () => api<StatementData>(`/partners/${id}/statement?month=${month}`), enabled: /^\d{4}-\d{2}$/.test(month) });
  const params = new URLSearchParams({ month });
  return (
    <Panel
      title="Monthly statement"
      freshness="Sales by the month they happened (Kigali time), with the split under the terms in force that day."
      actions={
        <div className="flex flex-wrap items-center gap-2">
          <label htmlFor="st-month" className="sr-only">
            Month
          </label>
          <input id="st-month" type="month" className={`${inputClass} w-[160px]`} value={month} max={thisMonth()} onChange={(e) => setMonth(e.target.value)} />
          {canExport && <ExportButton path={`/partners/${id}/statement.csv`} params={params} label="CSV" />}
        </div>
      }
    >
      {q.isLoading ? (
        <Skeleton className="h-32 w-full" />
      ) : q.error ? (
        <ErrorState message={(q.error as Error).message} requestId={(q.error as ApiError).requestId} onRetry={() => q.refetch()} />
      ) : !q.data?.byCurrency.length ? (
        <p className="py-6 text-[13px] text-ink-muted">No shared sales in this month.</p>
      ) : (
        q.data.byCurrency.map((b) => (
          <div key={b.currency} className="flex flex-col gap-3">
            <Table minWidth={860} head={['Paid with', { label: 'Sales', align: 'right' }, { label: 'Tickets', align: 'right' }, { label: 'Commission', align: 'right' }, { label: 'Aggregator fees', align: 'right' }, { label: 'Sinc keeps', align: 'right' }, { label: 'Blocker', align: 'right' }, { label: 'Operator share', align: 'right' }]}>
              {[...b.byGateway, { gateway: 'Total', ...b.totals }].map((g) => (
                <tr key={g.gateway} className={`h-11 border-b border-line ${g.gateway === 'Total' ? 'font-medium' : ''}`}>
                  <td className={tdFirst}>{g.gateway === 'Total' ? 'Total' : humanize(g.gateway)}</td>
                  <td className={`num ${td} text-right`}>{fmt('count', g.sales)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', g.gross, b.currency)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', g.commission, b.currency)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', g.aggregatorFee, b.currency)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', g.sincKeep, b.currency)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', g.blocker, b.currency)}</td>
                  <td className={`num ${tdLast} text-right`}>{fmt('money', g.operatorShare, b.currency)}</td>
                </tr>
              ))}
            </Table>
            <p className="text-[12px] text-ink-muted">
              Credited so far for this month: {fmt('money', q.data!.operatorCredited.amount, b.currency)} ({fmt('count', q.data!.operatorCredited.count)} {q.data!.operatorCredited.count === 1 ? 'credit' : 'credits'}).
            </p>
          </div>
        ))
      )}
    </Panel>
  );
}

/* ------------------------------------------------------------------ per event */
interface EventShare {
  rank: number;
  eventId: number | null;
  name: string | null;
  currency: string;
  sales: number;
  gross: number;
  commission: number;
  aggregatorFee: number;
  operatorShare: number;
  sincKeep: number;
  sharePct: number | null;
}

function ByEvent({ id }: { id: number }) {
  const { params } = useScopeParams();
  const qs = new URLSearchParams({ from: params.get('from')!, to: params.get('to')! });
  const pager = useOffsetPager<EventShare, { items: EventShare[]; total: number; from: string; to: string }>(`/partners/${id}/events`, qs, (r) => ({ items: r.items, total: r.total }), { initialSize: 10 });
  return (
    <Panel
      title="Share per event"
      freshness="For the period at the top of the page. The operator's percentage differs by event because each organizer's commission and each provider's fee differ."
    >
      {pager.isLoading ? (
        <Skeleton className="h-32 w-full" />
      ) : pager.error ? (
        <ErrorState message={(pager.error as Error).message} onRetry={() => pager.refetch()} />
      ) : !pager.items.length ? (
        <p className="py-6 text-[13px] text-ink-muted">No shared sales in this period.</p>
      ) : (
        <>
          <Table minWidth={860} head={[{ label: 'Rank', align: 'right' }, 'Event', { label: 'Sales', align: 'right' }, { label: 'Tickets', align: 'right' }, { label: 'Commission', align: 'right' }, { label: 'Operator share', align: 'right' }, { label: 'Of ticket price', align: 'right' }]}>
            {pager.items.map((e) => (
              <tr key={`${e.eventId}-${e.currency}`} className="h-11 border-b border-line">
                <td className={`num ${tdFirst} text-right`}>#{e.rank}</td>
                <td className={`${td} max-w-[300px] truncate`}>
                  {e.eventId ? (
                    <Link href={`?event=${e.eventId}`} scroll={false} className="underline decoration-line-strong underline-offset-4">
                      {e.name ?? `Event #${e.eventId}`}
                    </Link>
                  ) : (
                    <span className="text-ink-muted" title="The sale could not be matched to a ticket or sign-up">
                      Not matched to an event
                    </span>
                  )}
                </td>
                <td className={`num ${td} text-right`}>{fmt('count', e.sales)}</td>
                <td className={`num ${td} text-right`}>{fmt('money', e.gross, e.currency)}</td>
                <td className={`num ${td} text-right`}>{fmt('money', e.commission, e.currency)}</td>
                <td className={`num ${td} text-right`}>{fmt('money', e.operatorShare, e.currency)}</td>
                <td className={`num ${tdLast} text-right`}>{e.sharePct === null ? '–' : `${(e.sharePct * 100).toFixed(2)}%`}</td>
              </tr>
            ))}
          </Table>
          <PagerBar pager={pager} noun="events" sizes={[10, 25, 50]} />
        </>
      )}
    </Panel>
  );
}

/* ------------------------------------------------------------------ sales */
interface SaleRow {
  transactionId: number;
  eventId: number | null;
  eventName: string | null;
  at: string;
  gateway: string;
  currency: string;
  gross: number;
  commission: number;
  aggregatorFee: number;
  royalty: number;
  blocker: number;
  operatorShare: number;
  sincKeep: number;
  shortfall: boolean;
  termsVersion: number;
  operatorStatus: string | null;
  operatorError: string | null;
}

const CREDIT_STATUS: Record<string, [React.ComponentProps<typeof StatusBadge>['status'], string]> = {
  applied: ['ok', 'Credited'],
  pending: ['pending', 'Queued'],
  claimed: ['pending', 'Crediting'],
  held: ['warning', 'Needs account'],
  failed: ['critical', 'Failed'],
};

function Sales({ id }: { id: number }) {
  const pager = useCursorPager<SaleRow>(`/partners/${id}/sales`, new URLSearchParams(), { urlSize: false, initialSize: 25 });
  return (
    <Panel title="Shared sales" freshness="Newest first. One line per payment in the partner's countries.">
      {pager.isLoading ? (
        <Skeleton className="h-40 w-full" />
      ) : pager.error ? (
        <ErrorState message={(pager.error as Error).message} onRetry={() => pager.refetch()} />
      ) : !pager.items.length ? (
        <p className="py-6 text-[13px] text-ink-muted">No shared sales yet. Sales appear here within a minute of the payment.</p>
      ) : (
        <>
          <Table minWidth={900} head={['Payment', 'When', { label: 'Ticket', align: 'right' }, { label: 'Commission', align: 'right' }, { label: 'Fee', align: 'right' }, { label: 'Sinc keeps', align: 'right' }, { label: 'Operator', align: 'right' }, 'Credit']}>
            {pager.items.map((s) => {
              const [tone, label] = CREDIT_STATUS[s.operatorStatus ?? ''] ?? ['info', s.operatorShare > 0 ? 'Unknown' : 'Nothing to credit'];
              return (
                <tr key={s.transactionId} className="h-11 border-b border-line">
                  <td className={`num ${tdFirst}`}>
                    <Link href={`/transactions/${s.transactionId}`} className="underline decoration-line-strong underline-offset-4">
                      #{s.transactionId}
                    </Link>
                    <div className="max-w-[220px] truncate text-[11px] text-ink-muted">
                      {s.eventName ?? (s.eventId ? `Event #${s.eventId}` : 'No event')} · {humanize(s.gateway)} · terms v{s.termsVersion}
                    </div>
                  </td>
                  <td className={`num ${td} whitespace-nowrap text-ink-secondary`}>{new Date(s.at).toLocaleString('en-GB', { timeZone: 'Africa/Kigali', dateStyle: 'medium', timeStyle: 'short' })}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', s.gross, s.currency)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', s.commission, s.currency)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', s.aggregatorFee, s.currency)}</td>
                  <td className={`num ${td} text-right`}>{fmt('money', s.sincKeep, s.currency)}</td>
                  <td className={`num ${td} text-right`} title={s.shortfall ? 'Commission was too low for the operator share; Sinc absorbed the difference' : undefined}>
                    {fmt('money', s.operatorShare, s.currency)}
                    {s.shortfall && <span className="ml-1 text-ember-ink">*</span>}
                  </td>
                  <td className={tdLast} title={s.operatorError ?? undefined}>
                    {s.operatorShare > 0 || s.operatorStatus ? <StatusBadge status={tone}>{label}</StatusBadge> : <span className="text-[12px] text-ink-muted">Nothing to credit</span>}
                  </td>
                </tr>
              );
            })}
          </Table>
          <PagerBar pager={pager} noun="sales" />
        </>
      )}
    </Panel>
  );
}

/* ------------------------------------------------------------------ actions */
function RetryFailed({ id, count }: { id: number; count: number }) {
  const qc = useQueryClient();
  const [reason, setReason] = useState('');
  const m = useMutation({
    mutationFn: () => api(`/partners/${id}/credits/retry`, { method: 'POST', json: { reason } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['partner', String(id)] }),
  });
  return (
    <Panel title={`${count} credits failed`} freshness="Usually Sinc's wallet for that provider was too low when the credit ran. Top it up or check the error on each sale below, then retry.">
      <form
        className="flex flex-wrap items-end gap-3"
        onSubmit={(e) => {
          e.preventDefault();
          m.mutate();
        }}
      >
        <div className="min-w-[260px] flex-1">
          <Field label="Reason (recorded in the audit log)" htmlFor="rt-reason">
            <input id="rt-reason" required minLength={5} className={inputClass} value={reason} onChange={(e) => setReason(e.target.value)} />
          </Field>
        </div>
        <Button type="submit" loading={m.isPending}>
          Retry failed credits
        </Button>
      </form>
      {m.error && <p className="mt-2 text-[12px] text-ember-ink">{(m.error as Error).message}</p>}
    </Panel>
  );
}

function EditPartner({ p }: { p: Detail }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: p.name, account: p.account ? String(p.account.id) : '', contactEmail: p.contactEmail ?? '', status: p.status, reason: '' });
  const m = useMutation({
    mutationFn: () =>
      api<{ released: number }>(`/partners/${p.id}`, {
        method: 'PATCH',
        json: { name: f.name, payoutOrganizerProfileId: f.account ? Number(f.account) : null, contactEmail: f.contactEmail || null, status: f.status, reason: f.reason },
      }),
    onSuccess: () => {
      setOpen(false);
      qc.invalidateQueries({ queryKey: ['partner', String(p.id)] });
    },
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  if (!open)
    return (
      <div>
        <Button variant="secondary" onClick={() => setOpen(true)}>
          Edit partner details
        </Button>
      </div>
    );
  return (
    <Panel title="Partner details" freshness="Changing the account only affects shares not credited yet. Suspending stops new shares; sales stay with Sinc.">
      <form
        className="grid grid-cols-1 gap-4 md:grid-cols-2"
        onSubmit={(e) => {
          e.preventDefault();
          m.mutate();
        }}
      >
        <Field label="Name" htmlFor="ep-name">
          <input id="ep-name" required className={inputClass} value={f.name} onChange={set('name')} />
        </Field>
        <Field label="Sinc operator account (organizer profile #)" htmlFor="ep-account">
          <input id="ep-account" type="number" min="2" className={inputClass} value={f.account} onChange={set('account')} />
        </Field>
        <Field label="Contact email" htmlFor="ep-email">
          <input id="ep-email" type="email" className={inputClass} value={f.contactEmail} onChange={set('contactEmail')} />
        </Field>
        <Field label="Status" htmlFor="ep-status">
          <select id="ep-status" className={inputClass} value={f.status} onChange={set('status')}>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
          </select>
        </Field>
        <div className="md:col-span-2">
          <Field label="Reason (recorded in the audit log)" htmlFor="ep-reason">
            <input id="ep-reason" required minLength={5} className={inputClass} value={f.reason} onChange={set('reason')} />
          </Field>
        </div>
        {m.error && <p className="text-[12px] text-ember-ink md:col-span-2">{(m.error as Error).message}</p>}
        <div className="flex gap-2 md:col-span-2">
          <Button type="submit" loading={m.isPending}>
            Save
          </Button>
          <Button type="button" variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
        </div>
      </form>
    </Panel>
  );
}

/* ------------------------------------------------------------------ dashboard access */
interface PartnerUser {
  id: number;
  name: string;
  email: string;
  status: string;
  twoFactor: boolean;
  lastLoginAt: string | null;
}

function PortalAccess({ id, canManage }: { id: number; canManage: boolean }) {
  const qc = useQueryClient();
  const users = useQuery({ queryKey: ['partner-users', id], queryFn: () => api<{ items: PartnerUser[] }>(`/partners/${id}/users`) });
  const [email, setEmail] = useState('');
  const [reason, setReason] = useState('');
  const [removing, setRemoving] = useState<number | null>(null);
  const add = useMutation({
    mutationFn: () => api(`/partners/${id}/users`, { method: 'POST', json: { email, reason } }),
    onSuccess: () => {
      setEmail('');
      setReason('');
      qc.invalidateQueries({ queryKey: ['partner-users', id] });
    },
  });
  const remove = useMutation({
    mutationFn: (staffId: number) => api(`/partners/${id}/users/${staffId}/remove`, { method: 'POST', json: { reason } }),
    onSuccess: () => {
      setRemoving(null);
      setReason('');
      qc.invalidateQueries({ queryKey: ['partner-users', id] });
    },
  });
  return (
    <Panel
      title="Dashboard access"
      freshness="People at the partner sign in to this console with their Sinc account and 2FA, and see only this partnership. They don't need the ADMIN role, and must not have it."
      actions={
        <Link href={`/portal?partnerId=${id}`} className="text-[13px] underline decoration-ember underline-offset-4">
          See their dashboard
        </Link>
      }
    >
      {users.isLoading ? (
        <Skeleton className="h-20 w-full" />
      ) : !users.data?.items.length ? (
        <p className="text-[13px] text-ink-muted">Nobody yet.</p>
      ) : (
        <ul className="flex flex-col">
          {users.data.items.map((u) => (
            <li key={u.id} className="flex flex-wrap items-center justify-between gap-3 border-b border-line py-2 text-[13px]">
              <span>
                <span className="text-ink">{u.name}</span> <span className="text-ink-secondary">{u.email}</span>
                <span className="ml-2 text-[12px] text-ink-muted">
                  {u.status === 'ACTIVE' ? (u.twoFactor ? (u.lastLoginAt ? `last signed in ${new Date(u.lastLoginAt).toLocaleDateString('en-GB')}` : '2FA set, never signed in') : 'has not set up 2FA yet') : 'removed'}
                </span>
              </span>
              {canManage && u.status === 'ACTIVE' && (
                <Button variant="quiet" onClick={() => setRemoving(u.id)}>
                  Remove
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}
      {canManage && (
        <form
          className="mt-4 grid grid-cols-1 gap-3 bg-fog p-4 md:grid-cols-[1fr_1fr_auto] md:items-end"
          onSubmit={(e) => {
            e.preventDefault();
            if (removing) remove.mutate(removing);
            else add.mutate();
          }}
        >
          {!removing && (
            <Field label="Their Sinc account email" htmlFor="pu-email">
              <input id="pu-email" type="email" required className={inputClass} value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
          )}
          <Field label={removing ? 'Why remove their access? (audit log)' : 'Reason (audit log)'} htmlFor="pu-reason">
            <input id="pu-reason" required minLength={5} className={inputClass} value={reason} onChange={(e) => setReason(e.target.value)} />
          </Field>
          <div className="flex gap-2">
            <Button type="submit" loading={add.isPending || remove.isPending}>
              {removing ? 'Remove access' : 'Give access'}
            </Button>
            {removing && (
              <Button type="button" variant="secondary" onClick={() => setRemoving(null)}>
                Cancel
              </Button>
            )}
          </div>
          {(add.error || remove.error) && <p className="text-[12px] text-ember-ink md:col-span-3">{((add.error || remove.error) as Error).message}</p>}
        </form>
      )}
    </Panel>
  );
}
