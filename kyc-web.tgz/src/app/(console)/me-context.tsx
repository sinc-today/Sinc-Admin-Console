'use client';

import { createContext, useContext } from 'react';
import type { StaffMe } from '@/lib/server-api';

const MeContext = createContext<StaffMe | null>(null);

export function MeProvider({ value, children }: { value: StaffMe; children: React.ReactNode }) {
  return <MeContext.Provider value={value}>{children}</MeContext.Provider>;
}

export function useMe() {
  const me = useContext(MeContext);
  if (!me) throw new Error('useMe must be used inside the console layout');
  return me;
}

export function useCan(permission: string) {
  return useMe().permissions.includes(permission);
}
