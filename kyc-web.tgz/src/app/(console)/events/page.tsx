'use client';

import { useQuery } from '@tanstack/react-query';
import { parseAsInteger, parseAsString, useQueryState, useQueryStates } from 'nuqs';
import { Flyer } from '@/components/Flyer';
import { NoAccess } from '@/components/PhasePlaceholder';
import { fmt } from '@/components/analytics-ui';
import { ExportButton, ListState, RowLink, SavedViews, SearchForm, SelectField, Table, dayFmt, td, tdFirst, tdLast } from '@/components/directory-ui';
import { PagerBar, useCursorPager } from '@/components/pager';
import { Button, Panel, StatusBadge } from '@/components/ui';
import { api } from '@/lib/api';
import { useCan } from '../me-context';

interface EventRow {
  id: number;
  name: string;
  flyer: string | null;
  organizerProfileId: number | null;
  organizer: string | null;
  category: string | null;
  startDate: string;
  endDate: string;
  country: string | null;
  currency: string | null;
  privacy: string | null;
  sold: number;
  capacity: number;
  sellThrough: number | null;
  scanned: number;
  revenue: number;
  processed: number;
  attendanceRate: number | null;
  rank: number;
  ranked: number;
  status: 'upcoming' | 'live' | 'ended';
}

const SORTS = [
  { value: 'processed', label: 'Amount processed' },
  { value: 'sold', label: 'Tickets sold' },
  { value: 'attendance', label: 'Attendance' },
];

const STATUS = { upcoming: ['info', 'Upcoming'], live: ['ok', 'Live'], ended: ['pending', 'Ended'] } as const;

export default function EventsPage() {
  const can = useCan('analytics.read');
  const [f, setF] = useQueryStates({ q: parseAsString, status: parseAsString, category: parseAsString, eventCountry: parseAsString, privacy: parseAsString, sort: parseAsString });
  const [, setEvent] = useQueryState('event', parseAsInteger);
  const cats = useQuery({ queryKey: ['event-categories'], queryFn: () => api<{ items: { id: number; name: string }[] }>('/events/categories'), enabled: can, staleTime: 600_000 });
  const params = new URLSearchParams();
  Object.entries(f).forEach(([k, v]) => v && params.set(k, v));
  const q = useCursorPager<EventRow>('/events', params, { enabled: can });
  if (!can) return <NoAccess />;
  const items = q.items;
  const exportParams = new URLSearchParams(params);
  exportParams.delete('limit');
  exportParams.delete('sort');
  const ranked = !!f.sort && f.sort !== 'newest';
  return (
    <div className="flex flex-col gap-5">
      <Panel
        title="Find events"
        actions={
          <>
            <SavedViews page="events" />
            <ExportButton path="/exports/events.csv" params={exportParams} />
          </>
        }
      >
        <SearchForm id="e-q" label="Event id or name" initial={f.q ?? ''} onSearch={(v) => setF({ q: v })} />
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-5">
          <SelectField id="e-s" label="Status" value={f.status} onChange={(v) => setF({ status: v })} options={[{ value: 'upcoming', label: 'Upcoming' }, { value: 'live', label: 'Live now' }, { value: 'ended', label: 'Ended' }]} />
          <SelectField id="e-c" label="Category" value={f.category} onChange={(v) => setF({ category: v })} options={(cats.data?.items ?? []).map((c) => ({ value: String(c.id), label: c.name }))} />
          <SelectField id="e-k" label="Country" value={f.eventCountry} onChange={(v) => setF({ eventCountry: v })} options={[{ value: 'RWA', label: 'Rwanda' }, { value: 'UGA', label: 'Uganda' }]} />
          <SelectField id="e-p" label="Privacy" value={f.privacy} onChange={(v) => setF({ privacy: v })} options={[{ value: 'PUBLIC', label: 'Public' }, { value: 'PRIVATE', label: 'Private' }]} />
          <SelectField id="e-sort" label="Rank by (default: newest)" value={f.sort} onChange={(v) => setF({ sort: v })} options={SORTS} />
        </div>
      </Panel>
      <Panel
        title="Events"
        freshness={`${ranked ? `Ranked by ${SORTS.find((x) => x.value === f.sort)?.label.toLowerCase()}` : 'Newest first'}. Rank is by amount processed among the events matching these filters, per currency. Lifetime figures, live from the events database. Select an event to see its details.`}
      >
        <ListState q={q} count={items.length} emptyTitle="No events match" emptyBody="Clear a filter or search for a different name.">
          <Table
            head={[
              { label: 'Rank', align: 'right' },
              'Event',
              'Organizer',
              'Starts',
              'Status',
              { label: 'Amount processed', align: 'right' },
              { label: 'Sold', align: 'right' },
              { label: 'Sell-through', align: 'right' },
              { label: 'Attendance', align: 'right' },
            ]}
            minWidth={1180}
          >
            {items.map((e) => (
              <tr key={e.id} className="h-16 border-b border-line hover:bg-fog">
                <td className={`num ${tdFirst} text-right`} title={`#${e.rank} of ${e.ranked} ${e.currency ?? ''} events by amount processed`}>
                  #{e.rank}
                </td>
                <td className={`${td} max-w-[320px]`}>
                  <button type="button" onClick={() => setEvent(e.id)} className="flex w-full min-w-0 items-center gap-3 text-left" aria-label={`${e.name}, event ${e.id}: open details`}>
                    <Flyer src={e.flyer} name={e.name} className="size-11" />
                    <span className="min-w-0">
                      <span className="block truncate text-ink underline decoration-line-strong underline-offset-4">{e.name}</span>
                      <span className="block truncate text-[12px] text-ink-muted">
                        #{e.id}
                        {e.category && ` · ${e.category}`}
                        {e.privacy === 'PRIVATE' && ' · private'}
                      </span>
                    </span>
                  </button>
                </td>
                <td className={`${td} max-w-[180px] truncate`}>{e.organizerProfileId ? <RowLink href={`/organizers/${e.organizerProfileId}`}>{e.organizer ?? `#${e.organizerProfileId}`}</RowLink> : 'None'}</td>
                <td className={`num ${td} whitespace-nowrap text-ink-secondary`}>{dayFmt(e.startDate)}</td>
                <td className={td}>
                  <StatusBadge status={STATUS[e.status][0]}>{STATUS[e.status][1]}</StatusBadge>
                </td>
                <td className={`num ${td} text-right`}>{e.processed ? fmt('money', e.processed, e.currency ?? 'RWF') : <span className="text-ink-muted">None</span>}</td>
                <td className={`num ${td} text-right`}>{fmt('count', e.sold)}</td>
                <td className={`num ${td} text-right`}>{fmt('ratio', e.sellThrough)}</td>
                <td className={`num ${tdLast} text-right`}>
                  {e.sold ? (
                    <>
                      {fmt('count', e.scanned)}
                      <span className="ml-1 text-[12px] text-ink-muted">{fmt('ratio', e.attendanceRate)}</span>
                    </>
                  ) : (
                    <span className="text-ink-muted">No data</span>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        </ListState>
        <PagerBar pager={q} noun="events" />
      </Panel>
    </div>
  );
}
