'use client';

import { PagerBar, useCursorPager } from '@/components/pager';
import Link from 'next/link';
import { parseAsString, useQueryStates } from 'nuqs';
import { useState } from 'react';
import { NoAccess } from '@/components/PhasePlaceholder';
import { TxStatus } from '@/components/TxStatus';
import { fmt, humanize } from '@/components/analytics-ui';
import { Button, EmptyState, ErrorState, Field, inputClass, Panel, Skeleton } from '@/components/ui';
import { useScopeParams } from '@/lib/analytics';
import { api, ApiError } from '@/lib/api';
import { formatDateTime } from '@/lib/format';
import { useProviders } from '@/lib/providers';
import { useCan } from '../me-context';

interface Tx {
  id: number;
  createdAt: string;
  amount: number;
  currency: string;
  status: string;
  transactionType: string;
  paymentGateway: string | null;
  correspondent: string | null;
  flow: string | null;
  country: string;
  organizer: string | null;
  errorMessage: string | null;
}

const TYPES = ['TICKET_PAYMENT', 'PRODUCT_PAYMENT', 'GROUP_MEMBERSHIP', 'COMMISSION_COLLECTION', 'WITHDRAW', 'REVERSE_PAYMENT', 'PLAN_PAYMENT', 'MESSAGE_PAYMENT', 'EVENT_POST_PAYMENT', 'AFFILIATION', 'COLLABORATION', 'PARTNER_SHARE'];
const NETWORKS = ['MTN_MOMO_RWA', 'AIRTEL_RWA', 'MTN_MOMO_UGA', 'AIRTEL_OAPI_UGA', 'CARD', 'CASH', 'POS', 'SINC'];

export default function TransactionsPage() {
  const can = useCan('money.read');
  const providers = useProviders();
  const { params } = useScopeParams();
  const [f, setF] = useQueryStates({
    status: parseAsString,
    type: parseAsString,
    gateway: parseAsString,
    correspondent: parseAsString,
    flow: parseAsString,
    q: parseAsString,
  });
  const [search, setSearch] = useState(f.q ?? '');

  const txParams = new URLSearchParams(params);
  Object.entries(f).forEach(([k, v]) => v && txParams.set(k, v));
  const q = useCursorPager<Tx>('/transactions', txParams, { enabled: can });

  if (!can) return <NoAccess />;
  const items = q.items;
  // Providers are discovered by the admin service (known, priced, or seen in payments), plus Sinc's own channels.
  const gateways = [...(providers.data?.providers.map((p) => p.code) ?? []), 'MANUAL', 'SINC'];
  const select = (key: keyof typeof f, label: string, options: string[]) => (
    <Field label={label} htmlFor={`f-${key}`}>
      <select id={`f-${key}`} value={f[key] ?? ''} onChange={(e) => setF({ [key]: e.target.value || null })} className={inputClass}>
        <option value="">All</option>
        {options.map((o) => (
          <option key={o} value={o}>
            {humanize(o)}
          </option>
        ))}
      </select>
    </Field>
  );

  return (
    <div className="flex flex-col gap-5">
      <Panel title="Find transactions">
        <form
          className="mb-4 flex max-w-[640px] items-end gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            setF({ q: search.trim() || null });
          }}
        >
          <div className="flex-1">
            <Field label="Transaction id or reference" htmlFor="f-q" helper="Exact match on id, tx_ref or provider id. Ignores the date range.">
              <input id="f-q" value={search} onChange={(e) => setSearch(e.target.value)} className={inputClass} />
            </Field>
          </div>
          <div className="flex gap-2 pb-[22px]">
            <Button type="submit">Search</Button>
            {f.q && (
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setSearch('');
                  setF({ q: null });
                }}
              >
                Clear
              </Button>
            )}
          </div>
        </form>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
          {select('status', 'Status', ['SUCCESS', 'FAILED', 'PENDING'])}
          {select('type', 'Type', TYPES)}
          {select('correspondent', 'Network', NETWORKS)}
          {select('gateway', 'Provider', gateways)}
          {select('flow', 'Direction', ['INCOMING', 'OUTGOING'])}
        </div>
      </Panel>

      <Panel title="Transactions" freshness="Newest first, live from the payments database">
        {q.isLoading ? (
          <div className="flex flex-col gap-3" role="status" aria-label="Loading">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : q.error ? (
          <ErrorState message={(q.error as Error).message} requestId={(q.error as ApiError).requestId} onRetry={() => q.refetch()} />
        ) : items.length === 0 ? (
          <EmptyState title="No transactions match" body="Try a wider date range in the scope bar or clear some filters." />
        ) : (
          <div className="relative -mx-6 overflow-x-auto">
            <table className="w-full min-w-[980px] border-collapse text-[13px]">
              <thead>
                <tr className="bg-fog text-left text-[12px] text-ink-secondary">
                  <th scope="col" className="h-10 px-6 font-medium">Id</th>
                  <th scope="col" className="px-4 font-medium">When (Kigali)</th>
                  <th scope="col" className="px-4 font-medium">Type</th>
                  <th scope="col" className="px-4 font-medium">Organizer</th>
                  <th scope="col" className="px-4 font-medium">Network</th>
                  <th scope="col" className="px-4 font-medium">Status</th>
                  <th scope="col" className="px-6 text-right font-medium">Amount</th>
                </tr>
              </thead>
              <tbody>
                {items.map((t) => (
                  <tr key={t.id} className="h-11 border-b border-line hover:bg-fog">
                    <td className="num px-6">
                      <Link href={`/transactions/${t.id}`} className="text-ink underline decoration-ember underline-offset-4">
                        {t.id}
                      </Link>
                    </td>
                    <td className="num whitespace-nowrap px-4 text-ink-secondary">{formatDateTime(t.createdAt)}</td>
                    <td className="px-4 text-ink">
                      {humanize(t.transactionType)}
                      {t.flow === 'OUTGOING' && <span className="ml-1.5 text-[12px] text-ink-muted">out</span>}
                    </td>
                    <td className="max-w-[200px] truncate px-4 text-ink-secondary">{t.organizer ?? 'None'}</td>
                    <td className="px-4 text-ink-secondary">{humanize(t.correspondent)}</td>
                    <td className="px-4" title={t.errorMessage ?? undefined}>
                      <TxStatus status={t.status} />
                    </td>
                    <td className="num px-6 text-right text-ink">{fmt('money', t.amount, t.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <PagerBar pager={q} noun="transactions" />
      </Panel>
    </div>
  );
}
