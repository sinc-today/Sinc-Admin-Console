'use client';

import Link from 'next/link';
import { NoAccess } from '@/components/PhasePlaceholder';
import { BarList, MetricTile, QueryPanel, TrendChart, humanize } from '@/components/analytics-ui';
import { ErrorState, FeaturePanel, StatusBadge } from '@/components/ui';
import { freshnessLabel, useAnalytics, useScopeParams, type Freshness, type Kpi, type Series } from '@/lib/analytics';
import { ApiError } from '@/lib/api';
import { COMPARE_LABELS } from '@/lib/scope';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useCan, useMe } from './me-context';

interface Breakdowns {
  topEvents: { items: { id: number; name: string; amount: number; count: number }[]; unlinkedAmount: number };
  topOrganizers: { id: number | null; name: string; amount: number; count: number }[];
  channels: { channel: string; count: number; amount: number }[];
  correspondents: { correspondent: string; amount: number; count: number }[];
  signupMethods: { method: string; count: number }[];
}

const KPI_LINKS: Record<string, string> = {
  gmv: '/money?tab=collections',
  commission: '/money?tab=revenue',
  success_rate: '/money?tab=collections',
  tickets_sold: '/transactions?type=TICKET_PAYMENT',
};

export default function OverviewPage() {
  const me = useMe();
  const router = useRouter();
  useEffect(() => {
    if (me.staff.partnerId) router.replace('/portal');
  }, [me.staff.partnerId, router]);
  const can = useCan('analytics.read');
  const canMoney = useCan('money.read');
  const { currency, compare } = useScopeParams();
  const kpis = useAnalytics<{ kpis: Kpi[]; freshness: Freshness }>('/overview/kpis', {}, { enabled: can });
  const gmv = useAnalytics<{ series: Series; freshness: Freshness }>('/overview/series', { metric: 'gmv' }, { enabled: can });
  const br = useAnalytics<Breakdowns>('/overview/breakdowns', {}, { enabled: can });
  const attention = useAnalytics<{ items: { key: string; label: string; count: number; href: string; status: 'critical' | 'warning' }[] }>(
    '/overview/attention',
    {},
    { enabled: can, refetchMs: 60_000 }
  );

  if (!can) return <NoAccess />;
  const cmpLabel = compare === 'none' ? undefined : compare === 'yoy' ? 'vs last year' : 'vs previous';

  return (
    <div className="flex flex-col gap-5">
      {attention.data && attention.data.items.length > 0 && (
        <FeaturePanel tone="ivory" className="py-5">
          <h2 className="sr-only">Needs attention</h2>
          <ul className="flex flex-wrap gap-x-8 gap-y-3">
            {attention.data.items.map((i) => (
              <li key={i.key}>
                <Link href={i.href} className="group flex items-center gap-3">
                  <StatusBadge status={i.status}>
                    <span className="num">{i.count}</span>
                  </StatusBadge>
                  <span className="text-[14px] text-ink group-hover:underline group-hover:decoration-ember group-hover:underline-offset-4">{i.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </FeaturePanel>
      )}

      {kpis.error && !kpis.data ? (
        <ErrorState message={(kpis.error as Error).message} requestId={(kpis.error as ApiError).requestId} onRetry={() => kpis.refetch()} />
      ) : (
        <section aria-label="Key numbers" className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
          {(kpis.data?.kpis ?? Array.from({ length: 6 }).map(() => undefined)).map((k, i) => (
            <MetricTile key={k?.key ?? i} kpi={k} compareLabel={cmpLabel} href={k && canMoney ? KPI_LINKS[k.key] : undefined} />
          ))}
        </section>
      )}

      <QueryPanel title="GMV per day" freshness={freshnessLabel(gmv.data?.freshness)} query={gmv}>
        {(d) => <TrendChart series={d.series} compareLabel={COMPARE_LABELS[compare]} />}
      </QueryPanel>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[3fr_2fr]">
        <QueryPanel title="Top events by GMV" query={br} skeleton="list">
          {(d) => (
            <>
              <BarList
                rows={d.topEvents.items.map((e) => ({ label: e.name, value: e.amount, sub: `${e.count.toLocaleString('en')} payments` }))}
                unit="money"
                currency={currency}
                empty="No ticket payments in this period."
              />
              {d.topEvents.unlinkedAmount > 0 && (
                <p className="mt-4 text-[12px] text-ink-muted">
                  {new Intl.NumberFormat('en-RW', { maximumFractionDigits: 0 }).format(d.topEvents.unlinkedAmount)} {currency} of ticket payments couldn&apos;t be matched to an event.
                </p>
              )}
            </>
          )}
        </QueryPanel>
        <QueryPanel title="Top organizers by GMV" query={br} skeleton="list">
          {(d) => (
            <BarList
              rows={d.topOrganizers.map((o) => ({ label: o.name, value: o.amount, sub: `${o.count.toLocaleString('en')} payments` }))}
              unit="money"
              currency={currency}
              empty="No payments in this period."
            />
          )}
        </QueryPanel>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <QueryPanel title="Collections by network" query={br} skeleton="list">
          {(d) => (
            <BarList
              rows={d.correspondents.map((c) => ({ label: humanize(c.correspondent), value: c.amount, sub: `${c.count.toLocaleString('en')}` }))}
              unit="money"
              currency={currency}
              empty="No successful payments in this period."
            />
          )}
        </QueryPanel>
        <QueryPanel title="Paid sign-ups by channel" query={br} skeleton="list">
          {(d) => (
            <>
              <BarList
                rows={d.channels.map((c) => ({ label: humanize(c.channel), value: c.count }))}
                unit="count"
                empty="No paid sign-ups in this period."
              />
              <p className="mt-4 text-[12px] text-ink-muted">Includes cash and POS sales organizers record themselves, which aren&apos;t part of GMV.</p>
            </>
          )}
        </QueryPanel>
        <QueryPanel title="Signups by method" query={br} skeleton="list">
          {(d) => (
            <BarList
              rows={d.signupMethods.map((s) => ({ label: s.method === 'MANUAL' ? 'Email and password' : humanize(s.method), value: s.count }))}
              unit="count"
              empty="No new accounts in this period."
            />
          )}
        </QueryPanel>
      </div>
    </div>
  );
}
