'use client';

import { parseAsInteger, parseAsString, useQueryState, useQueryStates } from 'nuqs';
import { NoAccess } from '@/components/PhasePlaceholder';
import { CountryCode, ListState, RowLink, SavedViews, SearchForm, SelectField, Table, dayFmt, td, tdFirst, tdLast } from '@/components/directory-ui';
import { PagerBar, useCursorPager } from '@/components/pager';
import { Button, Panel, StatusBadge } from '@/components/ui';
import { COUNTRY_OPTIONS } from '@/lib/countries';
import { formatRelative } from '@/lib/format';
import { useCan } from '../me-context';

interface UserRow {
  id: number;
  username: string;
  name: string | null;
  email: string | null;
  registrationMethod: string | null;
  accountType: string | null;
  isBlocked: boolean;
  isVerified: boolean;
  createdAt: string;
  accessCountry: string | null;
  accessCountryName: string | null;
  lastActiveDay: string | null;
  lastSeenAt: string | null;
  lastPlatform: string | null;
}

export default function UsersPage() {
  const can = useCan('users.read');
  const [f, setF] = useQueryStates({ q: parseAsString, method: parseAsString, accountType: parseAsString, blocked: parseAsString, country: parseAsString, active: parseAsString });
  const [, openUser] = useQueryState('user', parseAsInteger);
  const params = new URLSearchParams();
  Object.entries(f).forEach(([k, v]) => v && params.set(k, v));
  const q = useCursorPager<UserRow>('/users', params, { enabled: can });
  if (!can) return <NoAccess />;
  const items = q.items;
  return (
    <div className="flex flex-col gap-5">
      <Panel title="Find users" actions={<SavedViews page="users" />}>
        <SearchForm id="u-q" label="User id, username, name or email" helper="Exact id, or the start of a username, name or email." initial={f.q ?? ''} onSearch={(v) => setF({ q: v })} />
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
          <SelectField
            id="u-active"
            label="Activity"
            value={f.active}
            onChange={(v) => setF({ active: v })}
            options={[
              { value: 'now', label: 'Active now (5 min)' },
              { value: 'today', label: 'Active today' },
              { value: '7d', label: 'Active in 7 days' },
              { value: '30d', label: 'Active in 30 days' },
              { value: 'inactive30', label: 'Inactive 30+ days' },
            ]}
          />
          <SelectField id="u-country" label="Access country" value={f.country} onChange={(v) => setF({ country: v })} options={COUNTRY_OPTIONS} />
          <SelectField id="u-method" label="Sign-in method" value={f.method} onChange={(v) => setF({ method: v })} options={[{ value: 'MANUAL', label: 'Email and password' }, { value: 'GOOGLE', label: 'Google' }, { value: 'APPLE', label: 'Apple' }]} />
          <SelectField id="u-type" label="Account type" value={f.accountType} onChange={(v) => setF({ accountType: v })} options={[{ value: 'personal', label: 'Personal' }, { value: 'business', label: 'Business' }]} />
          <SelectField id="u-blocked" label="Status" value={f.blocked} onChange={(v) => setF({ blocked: v })} options={[{ value: 'false', label: 'Active' }, { value: 'true', label: 'Blocked' }]} />
        </div>
      </Panel>
      <Panel title="Users" freshness="Newest first. Click a name to open the details pane; the id opens the full page.">
        <ListState q={q} count={items.length} emptyTitle="No users match" emptyBody="Clear a filter or search for a different name.">
          <Table head={['Id', 'User', 'Email', 'Sign-in', 'Access country', 'Joined', 'Last seen', 'Status']}>
            {items.map((u) => (
              <tr key={u.id} className="h-11 border-b border-line hover:bg-fog">
                <td className={`num ${tdFirst}`}>
                  <RowLink href={`/users/${u.id}`}>{u.id}</RowLink>
                </td>
                <td className={`${td} max-w-[220px] truncate`}>
                  <button type="button" onClick={() => openUser(u.id)} className="truncate text-left text-ink hover:underline hover:decoration-ember hover:underline-offset-4" aria-label={`Open details for ${u.name || u.username}`}>
                    {u.name || u.username}
                  </button>
                  {u.name && <span className="ml-1.5 text-[12px] text-ink-muted">@{u.username}</span>}
                </td>
                <td className={`${td} text-ink-secondary`}>{u.email ?? 'None'}</td>
                <td className={`${td} text-ink-secondary`}>{u.registrationMethod === 'MANUAL' ? 'Email' : u.registrationMethod ? u.registrationMethod.charAt(0) + u.registrationMethod.slice(1).toLowerCase() : 'Unknown'}</td>
                <td className={td}>
                  <CountryCode code={u.accessCountry} name={u.accessCountryName} />
                </td>
                <td className={`num ${td} whitespace-nowrap text-ink-secondary`}>{dayFmt(u.createdAt)}</td>
                <td className={`num ${td} whitespace-nowrap text-ink-secondary`}>
                  {u.lastSeenAt ? (
                    <>
                      {Date.now() - new Date(u.lastSeenAt).getTime() < 5 * 60_000 && <span aria-hidden className="mr-1.5 inline-block size-2 rounded-pill bg-ember" />}
                      {formatRelative(u.lastSeenAt)}
                      {u.lastPlatform && u.lastPlatform !== 'other' && <span className="ml-1.5 text-[12px] text-ink-muted">{u.lastPlatform === 'ios' ? 'iOS' : u.lastPlatform === 'android' ? 'Android' : 'Web'}</span>}
                    </>
                  ) : u.lastActiveDay ? (
                    dayFmt(`${u.lastActiveDay}T12:00:00Z`)
                  ) : (
                    'Not seen'
                  )}
                </td>
                <td className={tdLast}>{u.isBlocked ? <StatusBadge status="critical">Blocked</StatusBadge> : u.isVerified ? <StatusBadge status="ok">Verified</StatusBadge> : <StatusBadge status="info">Active</StatusBadge>}</td>
              </tr>
            ))}
          </Table>
        </ListState>
        <PagerBar pager={q} noun="users" />
      </Panel>
    </div>
  );
}
