import type { Icon } from '@phosphor-icons/react';
import {
  ChartLineUp,
  Broadcast,
  Coins,
  Handshake,
  Buildings,
  Storefront,
  TrendUp,
  Heart,
  MapTrifold,
  Tray,
  Pulse,
  Megaphone,
  Users,
  IdentificationBadge,
  CalendarBlank,
  Receipt,
  Percent,
  SquaresFour,
  UserGear,
  ClockCounterClockwise,
  ToggleRight,
} from '@phosphor-icons/react/dist/ssr';

export interface NavItem {
  href: string;
  label: string;
  icon: Icon;
  /** Permission needed to see the item; undefined = any staff. */
  permission?: string;
  /** Delivery phase from the implementation prompt; 0 = built, > 0 renders an "arrives in" empty state. */
  phase: number;
  description: string;
}

export interface NavGroup {
  label?: string;
  items: NavItem[];
}

export const NAV: NavGroup[] = [
  {
    items: [
      { href: '/', label: 'Overview', icon: ChartLineUp, permission: 'analytics.read', phase: 0, description: 'GMV, commission revenue, tickets, payment success, signups and active users at a glance.' },
      { href: '/live', label: 'Live', icon: Broadcast, permission: 'analytics.read', phase: 0, description: 'Orders, pending payments and ticket scans as they happen, for event nights and on-sale moments.' },
    ],
  },
  {
    label: 'Business',
    items: [
      { href: '/money', label: 'Money', icon: Coins, permission: 'money.read', phase: 0, description: 'Collections, payouts and wallets, reversals and commission revenue.' },
      { href: '/partners', label: 'Partners', icon: Handshake, permission: 'partners.read', phase: 0, description: 'Licence operators: their terms, shares of each sale, payouts and statements.' },
      { href: '/portal', label: 'Partner dashboard', icon: Buildings, permission: 'partner.portal', phase: 0, description: 'What a licence partner sees: earnings, share per event, statements, their countries and the ranking.' },
      { href: '/marketplace', label: 'Marketplace', icon: Storefront, permission: 'analytics.read', phase: 0, description: 'Events on sale, sell-through, organizers and affiliates.' },
      { href: '/growth', label: 'Growth', icon: TrendUp, permission: 'analytics.read', phase: 0, description: 'Signups, active users, retention cohorts and the purchase funnel.' },
      { href: '/engagement', label: 'Engagement', icon: Heart, permission: 'analytics.read', phase: 0, description: 'Posts, stories, likes, comments, search and push.' },
      { href: '/map', label: 'Map', icon: MapTrifold, permission: 'analytics.read', phase: 0, description: 'Events, sales density and audience by area, aggregated with a privacy floor.' },
    ],
  },
  {
    label: 'Operations',
    items: [
      { href: '/queues', label: 'Queues', icon: Tray, phase: 0, description: 'Organizer verification, KYC, commission requests, reported posts, feedback and failed payouts.' },
      { href: '/health', label: 'Health', icon: Pulse, permission: 'health.read', phase: 0, description: 'Services, routes, RabbitMQ, Postgres, payment providers, errors and scheduled jobs.' },
      { href: '/comms', label: 'Comms', icon: Megaphone, permission: 'comms.send', phase: 0, description: 'Bulk push notifications with preview, reach and two-person approval.' },
    ],
  },
  {
    label: 'Directory',
    items: [
      { href: '/users', label: 'Users', icon: Users, permission: 'users.read', phase: 0, description: 'Search users and open their full history.' },
      { href: '/organizers', label: 'Organizers', icon: IdentificationBadge, permission: 'organizers.read', phase: 0, description: 'Organizer profiles, verification, events, money and settlement accounts.' },
      { href: '/events', label: 'Events', icon: CalendarBlank, permission: 'analytics.read', phase: 0, description: 'Every event with tickets, sales curve, check-ins and channel mix.' },
      { href: '/transactions', label: 'Transactions', icon: Receipt, permission: 'money.read', phase: 0, description: 'Every payment, withdrawal and reversal with its full lifecycle.' },
    ],
  },
  {
    label: 'Settings',
    items: [
      { href: '/settings/catalog', label: 'Catalog', icon: SquaresFour, permission: 'catalog.manage', phase: 0, description: 'Categories, event contexts, tags, plans and permissions.' },
      { href: '/settings/staff', label: 'Staff & roles', icon: UserGear, permission: 'staff.read', phase: 0, description: 'Who has access to the console and what they can do.' },
      { href: '/settings/audit', label: 'Audit log', icon: ClockCounterClockwise, permission: 'audit.read', phase: 0, description: 'Every staff action, newest first.' },
      { href: '/settings/fees', label: 'Fees & SMS prices', icon: Percent, permission: 'money.read', phase: 0, description: 'Aggregator fee rates and SMS prices, versioned by date.' },
      { href: '/settings/flags', label: 'Feature flags', icon: ToggleRight, permission: 'flags.write', phase: 0, description: 'Roll features out by percentage and country.' },
    ],
  },
];

export const ALL_NAV_ITEMS = NAV.flatMap((g) => g.items);

export const findNavItem = (pathname: string): NavItem | undefined =>
  ALL_NAV_ITEMS.find((i) => (i.href === '/' ? pathname === '/' : pathname === i.href || pathname.startsWith(`${i.href}/`)));
