'use client';

import clsx from 'clsx';
import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { SidebarSimple } from '@phosphor-icons/react';
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { NAV } from '@/lib/nav';
import { api } from '@/lib/api';

const SCOPE_KEYS = ['range', 'from', 'to', 'cmp', 'country', 'cur'];

/** Left rail: 240px, collapsible to a 64px icon rail; remembers the choice per browser. */
export function Rail({ permissions, partner = false }: { permissions: string[]; partner?: boolean }) {
  const pathname = usePathname();
  const params = useSearchParams();
  const [collapsed, setCollapsed] = useState(false);
  // Open items across the queues this person can work; shown on Queues only when non-zero.
  const queues = useQuery({ queryKey: ['queues'], queryFn: () => api<{ total: number }>('/queues'), refetchInterval: 120_000, staleTime: 60_000, enabled: !partner });
  const badges: Record<string, number> = { '/queues': queues.data?.total ?? 0 };

  // Below 1280px the rail starts collapsed (prompt 8.9); an explicit choice is remembered per browser.
  useEffect(() => {
    let stored: string | null = null;
    try {
      stored = localStorage.getItem('sinc-admin-rail');
    } catch {
      /* storage unavailable */
    }
    setCollapsed(stored ? stored === 'collapsed' : window.matchMedia('(max-width: 1279px)').matches);
  }, []);

  const toggle = () => {
    setCollapsed((c) => {
      try {
        localStorage.setItem('sinc-admin-rail', c ? 'expanded' : 'collapsed');
      } catch {
        /* ignore */
      }
      return !c;
    });
  };

  // Carry the global scope across pages.
  const scopeQuery = (() => {
    const q = new URLSearchParams();
    SCOPE_KEYS.forEach((k) => {
      const v = params.get(k);
      if (v) q.set(k, v);
    });
    const s = q.toString();
    return s ? `?${s}` : '';
  })();

  // Partner accounts see only the partner dashboard.
  const can = (p?: string) => (partner ? p === 'partner.portal' : !p || permissions.includes(p));

  return (
    <nav
      aria-label="Main"
      className={clsx(
        'sticky top-0 flex h-dvh shrink-0 flex-col overflow-y-auto bg-ash py-4 transition-[width] duration-150 ease-ledger',
        collapsed ? 'w-16 px-2' : 'w-60 px-3'
      )}
    >
      <div className={clsx('mb-6 flex h-10 items-center', collapsed ? 'justify-center' : 'justify-between px-3')}>
        {!collapsed && (
          <Link href={`/${scopeQuery}`} className="display text-[18px] leading-none text-ink">
            Sinc <span className="text-ink-muted">Admin</span>
          </Link>
        )}
        <button
          type="button"
          onClick={toggle}
          aria-label={collapsed ? 'Expand navigation' : 'Collapse navigation'}
          aria-expanded={!collapsed}
          className="flex size-10 items-center justify-center text-ink-secondary hover:text-ink"
        >
          <SidebarSimple size={20} aria-hidden />
        </button>
      </div>

      <div className="flex flex-col gap-5">
        {NAV.map((group, gi) => {
          const items = group.items.filter((i) => can(i.permission));
          if (items.length === 0) return null;
          return (
            <div key={group.label ?? gi}>
              {group.label && !collapsed && <p className="mb-1 px-3 text-[12px] font-medium text-ink-muted">{group.label}</p>}
              <ul className="flex flex-col gap-0.5">
                {items.map((item) => {
                  const active = item.href === '/' ? pathname === '/' : pathname === item.href || pathname.startsWith(`${item.href}/`);
                  const Icon = item.icon;
                  return (
                    <li key={item.href}>
                      <Link
                        href={`${item.href}${scopeQuery}`}
                        aria-current={active ? 'page' : undefined}
                        title={collapsed ? item.label : undefined}
                        className={clsx(
                          'display relative flex h-10 items-center gap-3 rounded-pill text-[16px] leading-none transition-colors duration-150',
                          collapsed ? 'justify-center px-0' : 'px-3',
                          active ? 'bg-canvas text-ink' : 'text-ink-secondary hover:bg-fog hover:text-ink'
                        )}
                      >
                        {active && <span aria-hidden className="absolute left-0 top-2.5 h-5 w-0.5 bg-ember" />}
                        <Icon size={20} weight="regular" aria-hidden />
                        {!collapsed && <span className="truncate">{item.label}</span>}
                        {!!badges[item.href] && (
                          <span
                            className={clsx('num rounded-tag bg-ink px-1.5 text-[11px] leading-[18px] text-canvas', collapsed ? 'absolute right-1 top-0.5' : 'ml-auto')}
                            aria-label={`${badges[item.href]} open`}
                          >
                            {badges[item.href] > 99 ? '99+' : badges[item.href]}
                          </span>
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </div>
    </nav>
  );
}
