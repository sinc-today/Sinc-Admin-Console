'use client';

import * as Popover from '@radix-ui/react-popover';
import { SignOut } from '@phosphor-icons/react';
import { usePathname, useRouter } from 'next/navigation';
import { useState } from 'react';
import { api } from '@/lib/api';
import { findNavItem } from '@/lib/nav';
import { CommandPalette } from './CommandPalette';
import { ScopePill } from './ScopePill';

export function TopBar({ staff, environment, partner = false }: { staff: { displayName: string; email: string; role: { name: string } }; environment: string; partner?: boolean }) {
  const pathname = usePathname();
  const item = findNavItem(pathname);
  const title = item?.label ?? 'Sinc Admin';

  return (
    <header className="sticky top-0 z-30 flex h-16 min-w-0 items-center gap-4 bg-ash pr-6">
      <h1 className="display min-w-0 shrink truncate text-[32px] leading-none text-ink">{title}</h1>
      <div className="ml-2 hidden min-w-0 lg:block">
        <ScopePill />
      </div>
      <div className="ml-auto flex items-center gap-3">
        {!partner && <CommandPalette />}
        <EnvTag environment={environment} />
        <AccountMenu staff={staff} />
      </div>
    </header>
  );
}

function EnvTag({ environment }: { environment: string }) {
  const prod = environment === 'production';
  return (
    <span
      className={`inline-flex h-6 items-center rounded-tag px-2.5 text-[12px] font-medium ${prod ? 'bg-canvas text-ink' : 'bg-ivory text-brass-ink'}`}
      title={prod ? 'You are working on live data' : 'Not production'}
    >
      {prod ? 'PROD' : environment === 'staging' ? 'QA' : 'DEV'}
    </span>
  );
}

function AccountMenu({ staff }: { staff: { displayName: string; email: string; role: { name: string } } }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const initials = staff.displayName
    .split(/\s+/)
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const signOut = async () => {
    setBusy(true);
    try {
      await api('/auth/logout', { method: 'POST' });
    } finally {
      router.replace('/login');
    }
  };

  return (
    <Popover.Root>
      <Popover.Trigger
        aria-label={`Account: ${staff.displayName}`}
        className="display flex size-10 items-center justify-center rounded-pill bg-canvas text-[14px] text-ink hover:bg-fog"
      >
        {initials}
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content align="end" sideOffset={8} className="z-50 w-64 border border-line-strong bg-canvas p-4" style={{ borderRadius: 0 }}>
          <p className="display text-[16px] text-ink">{staff.displayName}</p>
          <p className="mt-0.5 text-[12px] text-ink-muted">{staff.email}</p>
          <p className="mt-2 text-[12px] font-medium text-ink-secondary">{staff.role.name}</p>
          <ThemePicker />
          <button
            type="button"
            onClick={signOut}
            disabled={busy}
            className="display mt-4 flex h-10 w-full items-center justify-center gap-2 border border-ink text-[15px] text-ink hover:bg-fog disabled:text-ink-disabled"
          >
            <SignOut size={16} aria-hidden /> Sign out
          </button>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}

const THEMES = [
  { key: 'system', label: 'System' },
  { key: 'light', label: 'Light' },
  { key: 'dark', label: 'Dark' },
] as const;

/** Light, dark or follow the system; remembered in this browser. */
function ThemePicker() {
  const [theme, setTheme] = useState<string>(() => {
    if (typeof document === 'undefined') return 'system';
    return document.documentElement.dataset.theme ?? 'system';
  });
  const pick = (t: string) => {
    setTheme(t);
    if (t === 'system') delete document.documentElement.dataset.theme;
    else document.documentElement.dataset.theme = t;
    try {
      if (t === 'system') localStorage.removeItem('sinc-admin-theme');
      else localStorage.setItem('sinc-admin-theme', t);
    } catch {
      /* storage unavailable */
    }
  };
  return (
    <div role="radiogroup" aria-label="Theme" className="mt-4 grid grid-cols-3 border border-line-strong">
      {THEMES.map((t) => (
        <button
          key={t.key}
          type="button"
          role="radio"
          aria-checked={theme === t.key}
          onClick={() => pick(t.key)}
          className={`h-8 text-[13px] ${theme === t.key ? 'bg-ink text-canvas' : 'text-ink hover:bg-fog'}`}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}
