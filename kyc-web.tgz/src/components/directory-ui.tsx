'use client';

import * as Popover from '@radix-ui/react-popover';
import { BookmarkSimple, DownloadSimple, Trash } from '@phosphor-icons/react';
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import clsx from 'clsx';
import Link from 'next/link';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { api, ApiError } from '@/lib/api';
import { Button, EmptyState, ErrorState, Field, inputClass, Skeleton, StatusBadge, type Status } from './ui';

/* ------------------------------------------------------------------ cursor-paged list */
export function useCursorList<T extends { id: number }>(path: string, params: URLSearchParams, enabled = true) {
  return useInfiniteQuery({
    queryKey: [path, params.toString()],
    enabled,
    initialPageParam: null as number | null,
    queryFn: ({ pageParam }) => {
      const qs = new URLSearchParams(params);
      if (pageParam) qs.set('cursor', String(pageParam));
      return api<{ items: T[]; nextCursor: number | null; currency?: string }>(`${path}?${qs}`);
    },
    getNextPageParam: (last) => last.nextCursor,
  });
}

/** Loading / error / empty states around a list body. */
export function ListState({
  q,
  count,
  emptyTitle,
  emptyBody,
  children,
}: {
  q: { isLoading: boolean; error: unknown; refetch: () => unknown };
  count: number;
  emptyTitle: string;
  emptyBody: string;
  children: React.ReactNode;
}) {
  if (q.isLoading)
    return (
      <div className="flex flex-col gap-3" role="status" aria-label="Loading">
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="h-10 w-full" />
        ))}
      </div>
    );
  if (q.error) return <ErrorState message={(q.error as Error).message} requestId={(q.error as ApiError).requestId} onRetry={() => q.refetch()} />;
  if (!count) return <EmptyState title={emptyTitle} body={emptyBody} />;
  return <>{children}</>;
}

/* ------------------------------------------------------------------ table primitives */
export function Table({ minWidth = 880, head, children }: { minWidth?: number; head: (string | { label: string; align?: 'right' })[]; children: React.ReactNode }) {
  return (
    <div className="relative -mx-6 overflow-x-auto">
      <table className="w-full border-collapse text-[13px]" style={{ minWidth }}>
        <thead>
          <tr className="bg-fog text-left text-[12px] text-ink-secondary">
            {head.map((h, i) => {
              const label = typeof h === 'string' ? h : h.label;
              const right = typeof h !== 'string' && h.align === 'right';
              return (
                <th key={label + i} scope="col" className={clsx('h-10 font-medium', i === 0 ? 'pl-6 pr-4' : i === head.length - 1 ? 'pl-4 pr-6' : 'px-4', right && 'text-right')}>
                  {label}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

export const tdFirst = 'pl-6 pr-4';
export const td = 'px-4';
export const tdLast = 'pl-4 pr-6';

export function RowLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="text-ink underline decoration-ember underline-offset-4">
      {children}
    </Link>
  );
}

/* ------------------------------------------------------------------ small facts */
export function Facts({ items, cols = 4 }: { items: { label: string; value: React.ReactNode; hint?: string }[]; cols?: 2 | 3 | 4 | 6 }) {
  return (
    <dl className={clsx('grid grid-cols-2 gap-x-6 gap-y-5', cols === 3 && 'md:grid-cols-3', cols === 4 && 'md:grid-cols-4', cols === 6 && 'md:grid-cols-3 xl:grid-cols-6')}>
      {items.map((it) => (
        <div key={it.label} className="min-w-0">
          <dt className="text-[12px] font-medium text-ink-secondary" title={it.hint}>
            {it.label}
          </dt>
          <dd className="num mt-1 truncate text-[16px] text-ink">{it.value}</dd>
        </div>
      ))}
    </dl>
  );
}

export function BigNumber({ label, value, sub }: { label: string; value: React.ReactNode; sub?: React.ReactNode }) {
  return (
    <div className="flex min-h-[120px] flex-col rounded-panel bg-canvas p-5">
      <p className="text-[12px] font-medium text-ink-secondary">{label}</p>
      <p className="display num mt-2 truncate text-[32px] leading-[1.19] text-ink">{value}</p>
      {sub && <p className="mt-1 text-[12px] text-ink-muted">{sub}</p>}
    </div>
  );
}

/** ISO 3166 alpha-2 shown as text, never as an emoji flag. */
export function CountryCode({ code, name }: { code: string | null | undefined; name?: string | null }) {
  if (!code || code === 'XX') return <span className="text-ink-muted">Unknown</span>;
  return (
    <span className="inline-flex items-baseline gap-2">
      <span className="num inline-flex h-5 min-w-7 items-center justify-center rounded-tag bg-fog px-1.5 text-[11px] font-medium text-ink">{code}</span>
      {name && <span className="truncate">{name}</span>}
    </span>
  );
}

/* ------------------------------------------------------------------ filters bar helpers */
export function SelectField({ id, label, value, onChange, options }: { id: string; label: string; value: string | null; onChange: (v: string | null) => void; options: { value: string; label: string }[] }) {
  return (
    <Field label={label} htmlFor={id}>
      <select id={id} value={value ?? ''} onChange={(e) => onChange(e.target.value || null)} className={inputClass}>
        <option value="">All</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </Field>
  );
}

export function SearchForm({ id, label, helper, initial, onSearch }: { id: string; label: string; helper?: string; initial: string; onSearch: (v: string | null) => void }) {
  const [v, setV] = useState(initial);
  return (
    <form
      className="flex max-w-[640px] items-end gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        onSearch(v.trim() || null);
      }}
    >
      <div className="flex-1">
        <Field label={label} htmlFor={id} helper={helper}>
          <input id={id} value={v} onChange={(e) => setV(e.target.value)} className={inputClass} autoComplete="off" />
        </Field>
      </div>
      <div className={clsx('flex gap-2', helper && 'pb-[22px]')}>
        <Button type="submit">Search</Button>
        {initial && (
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              setV('');
              onSearch(null);
            }}
          >
            Clear
          </Button>
        )}
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ CSV export */
export function ExportButton({ path, params, label = 'Export CSV' }: { path: string; params: URLSearchParams; label?: string }) {
  return (
    <a
      href={`/admin-api/v1${path}?${params}`}
      className="inline-flex h-10 items-center gap-2 bg-canvas px-3 text-[13px] font-medium text-ink outline outline-1 outline-line-strong hover:bg-fog"
      title="Downloads a CSV of the current filters. The export is recorded in the audit log."
    >
      <DownloadSimple size={16} aria-hidden /> {label}
    </a>
  );
}

/* ------------------------------------------------------------------ saved views */
interface SavedView {
  id: number;
  page: string;
  name: string;
  query: string;
  shared: boolean;
  mine: boolean;
}

/** Saved filter sets for a page. Search text is never saved, only filters. */
export function SavedViews({ page }: { page: string }) {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const qc = useQueryClient();
  const [name, setName] = useState('');
  const [shared, setShared] = useState(false);
  const list = useQuery({ queryKey: ['saved-views', page], queryFn: () => api<{ items: SavedView[] }>(`/saved-views?page=${page}`) });
  const save = useMutation({
    mutationFn: () => api<SavedView>('/saved-views', { method: 'POST', json: { page, name, query: sp.toString(), shared } }),
    onSuccess: () => {
      setName('');
      qc.invalidateQueries({ queryKey: ['saved-views', page] });
    },
  });
  const remove = useMutation({
    mutationFn: (id: number) => api(`/saved-views/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['saved-views', page] }),
  });
  const items = list.data?.items ?? [];
  return (
    <Popover.Root>
      <Popover.Trigger className="inline-flex h-10 items-center gap-2 bg-canvas px-3 text-[13px] font-medium text-ink outline outline-1 outline-line-strong hover:bg-fog">
        <BookmarkSimple size={16} aria-hidden /> Views{items.length ? ` (${items.length})` : ''}
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Content align="end" sideOffset={8} className="z-50 w-80 border border-line-strong bg-canvas p-4" style={{ borderRadius: 0 }}>
          <p className="display text-[16px] text-ink">Saved views</p>
          {items.length === 0 ? (
            <p className="mt-2 text-[13px] text-ink-muted">No saved views for this page yet.</p>
          ) : (
            <ul className="mt-2 flex flex-col">
              {items.map((v) => (
                <li key={v.id} className="flex items-center justify-between gap-2 border-b border-line py-2">
                  <button type="button" className="min-w-0 truncate text-left text-[13px] text-ink hover:underline hover:decoration-ember hover:underline-offset-4" onClick={() => router.push(`${pathname}?${v.query}`)}>
                    {v.name}
                    {v.shared && <span className="ml-2 text-[12px] text-ink-muted">shared</span>}
                  </button>
                  {v.mine && (
                    <button type="button" aria-label={`Delete view ${v.name}`} className="text-ink-muted hover:text-ink" onClick={() => remove.mutate(v.id)}>
                      <Trash size={16} aria-hidden />
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
          <form
            className="mt-4 flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (name.trim()) save.mutate();
            }}
          >
            <Field label="Save current filters as" htmlFor={`sv-${page}`} helper="The date range and filters are saved. Search text is not.">
              <input id={`sv-${page}`} value={name} onChange={(e) => setName(e.target.value)} maxLength={80} className={inputClass} />
            </Field>
            <label className="flex items-center gap-2 text-[13px] text-ink-secondary">
              <input type="checkbox" checked={shared} onChange={(e) => setShared(e.target.checked)} /> Share with all staff
            </label>
            <Button type="submit" loading={save.isPending} disabled={!name.trim()}>
              Save view
            </Button>
            {save.error && <p className="text-[12px] text-ember-ink">{(save.error as Error).message}</p>}
          </form>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
  );
}

export const dayFmt = (iso: string | null | undefined) =>
  iso ? new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'Africa/Kigali' }).format(new Date(iso)) : 'Never';

export const verificationBadge = (v: string | null) => {
  const map: Record<string, [Status, string]> = { APPROVED: ['ok', 'Approved'], PENDING: ['pending', 'Pending'], DECLINED: ['critical', 'Declined'] };
  const [s, l] = map[v ?? ''] ?? ['info', 'Not submitted'];
  return <StatusBadge status={s}>{l}</StatusBadge>;
};
