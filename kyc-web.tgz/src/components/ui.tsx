import clsx from 'clsx';
import { CheckCircle, Clock, WarningCircle, XCircle, Info } from '@phosphor-icons/react/dist/ssr';
import { forwardRef } from 'react';

/* ------------------------------------------------------------------ Button
 * Radius 0, PolySans/Inter Tight 16px, one line. Never orange-filled.
 */
type ButtonVariant = 'primary' | 'secondary' | 'quiet' | 'destructive';

export const Button = forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant; loading?: boolean; icon?: React.ReactNode }
>(function Button({ variant = 'primary', loading, icon, className, children, disabled, ...props }, ref) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={clsx(
        'display inline-flex h-10 min-w-10 items-center justify-center gap-2 whitespace-nowrap px-5 text-[16px] leading-none',
        'transition-[background-color,color,transform] duration-150 ease-ledger active:translate-y-px',
        'disabled:cursor-not-allowed disabled:active:translate-y-0',
        variant === 'primary' && 'bg-ink text-canvas hover:bg-ink-secondary disabled:bg-line-strong disabled:text-ink-muted',
        variant === 'secondary' && 'border border-ink bg-transparent text-ink hover:bg-fog disabled:border-line-strong disabled:text-ink-disabled',
        variant === 'quiet' && 'px-2 text-ink hover:underline hover:decoration-ember hover:underline-offset-4 disabled:text-ink-disabled',
        variant === 'destructive' && 'bg-ink text-canvas hover:bg-ink-secondary disabled:bg-line-strong disabled:text-ink-muted',
        className
      )}
      {...props}
    >
      {loading ? <Spinner /> : icon}
      {children}
    </button>
  );
});

const Spinner = () => (
  <span aria-hidden className="inline-block size-4 border-2 border-current border-r-transparent motion-safe:animate-spin" style={{ borderRadius: 999 }} />
);

/* ------------------------------------------------------------------ Tag */
export function Tag({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: 'neutral' | 'brass' }) {
  return (
    <span
      className={clsx(
        'inline-flex h-6 items-center rounded-tag px-2.5 text-[12px] font-medium leading-none',
        tone === 'neutral' ? 'bg-fog text-ink' : 'bg-fog text-brass'
      )}
    >
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ Status
 * Always icon + text; colour supplementary (prompt 8.3).
 */
export type Status = 'ok' | 'warning' | 'critical' | 'pending' | 'info';

const STATUS_STYLE: Record<Status, { cls: string; Icon: typeof CheckCircle }> = {
  ok: { cls: 'text-ink', Icon: CheckCircle },
  warning: { cls: 'bg-brass-wash text-brass-ink', Icon: WarningCircle },
  critical: { cls: 'bg-ember-wash text-ember-ink', Icon: XCircle },
  pending: { cls: 'text-ink-muted', Icon: Clock },
  info: { cls: 'text-ink-secondary', Icon: Info },
};

export function StatusBadge({ status, children }: { status: Status; children: React.ReactNode }) {
  const { cls, Icon } = STATUS_STYLE[status];
  return (
    <span className={clsx('inline-flex h-6 items-center gap-1.5 rounded-tag px-2 text-[12px] font-medium leading-none', cls)}>
      <Icon size={14} weight="regular" aria-hidden />
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ Delta
 * Bad direction in ember-ink, good/neutral in ink. Arrow always present.
 */
export function Delta({ value, polarity }: { value: number; polarity: 'up_is_good' | 'up_is_bad' | 'neutral' }) {
  const up = value >= 0;
  const bad = (polarity === 'up_is_good' && !up) || (polarity === 'up_is_bad' && up);
  return (
    <span className={clsx('num text-[12px] font-medium', bad ? 'text-ember-ink' : 'text-ink')}>
      <span aria-hidden>{up ? '▲' : '▼'}</span> {Math.abs(value * 100).toFixed(1)}%
      <span className="sr-only">{up ? ' increase' : ' decrease'}</span>
    </span>
  );
}

/* ------------------------------------------------------------------ Panels */
export function Panel({
  title,
  actions,
  freshness,
  children,
  className,
}: {
  title?: string;
  actions?: React.ReactNode;
  freshness?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={clsx('rounded-panel bg-canvas p-6', className)} aria-label={title}>
      {(title || actions) && (
        <header className="mb-4 flex items-start justify-between gap-4">
          <div>
            {title && <h2 className="display text-[16px] leading-tight text-ink">{title}</h2>}
            {freshness && <p className="mt-1 text-[12px] font-medium text-ink-muted">{freshness}</p>}
          </div>
          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </header>
      )}
      {children}
    </section>
  );
}

export function FeaturePanel({ children, tone = 'ash', className }: { children: React.ReactNode; tone?: 'ash' | 'ivory' | 'canvas'; className?: string }) {
  return (
    <section
      className={clsx(
        'rounded-feature p-6',
        tone === 'ash' && 'bg-ash',
        tone === 'ivory' && 'bg-ivory',
        tone === 'canvas' && 'bg-canvas',
        className
      )}
    >
      {children}
    </section>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <span aria-hidden className={clsx('skeleton block', className)} />;
}

/* ------------------------------------------------------------------ KPI tile */
export function KpiTile({
  label,
  definition,
  value,
  compare,
  loading,
  empty,
}: {
  label: string;
  definition: string;
  value?: string;
  compare?: React.ReactNode;
  loading?: boolean;
  empty?: string;
}) {
  return (
    <div className="flex min-h-[148px] flex-col rounded-panel bg-canvas p-5">
      <p className="text-[12px] font-medium text-ink-secondary" title={definition}>
        {label}
        <span className="sr-only">. {definition}</span>
      </p>
      {loading ? (
        <div className="mt-3 space-y-3" role="status" aria-label={`Loading ${label}`}>
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-3 w-24" />
          <Skeleton className="h-6 w-full" />
        </div>
      ) : empty ? (
        <p className="mt-3 text-[13px] text-ink-muted">{empty}</p>
      ) : (
        <>
          <p className="display num mt-2 text-[32px] leading-[1.19] text-ink">{value}</p>
          {compare && <div className="mt-1">{compare}</div>}
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ States */
export function EmptyState({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return (
    <FeaturePanel className="max-w-[640px]">
      <h3 className="display text-[18px] leading-tight text-ink">{title}</h3>
      <p className="mt-2 max-w-[65ch] text-[14px] text-ink-secondary">{body}</p>
      {action && <div className="mt-5">{action}</div>}
    </FeaturePanel>
  );
}

export function ErrorState({ message, requestId, onRetry }: { message: string; requestId?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="rounded-panel bg-canvas p-6">
      <StatusBadge status="critical">Couldn&apos;t load</StatusBadge>
      <p className="mt-3 text-[14px] text-ink">{message}</p>
      {requestId && <p className="mt-1 text-[12px] text-ink-muted">Request id {requestId}</p>}
      {onRetry && (
        <Button variant="secondary" className="mt-4" onClick={onRetry}>
          Retry
        </Button>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ Form fields */
export function Field({
  label,
  htmlFor,
  helper,
  error,
  children,
}: {
  label: string;
  htmlFor: string;
  helper?: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={htmlFor} className="text-[12px] font-medium text-ink">
        {label}
      </label>
      {children}
      {error ? (
        <p id={`${htmlFor}-error`} className="flex items-center gap-1.5 text-[12px] text-ember-ink">
          <WarningCircle size={14} aria-hidden /> {error}
        </p>
      ) : helper ? (
        <p id={`${htmlFor}-help`} className="text-[12px] text-ink-muted">
          {helper}
        </p>
      ) : null}
    </div>
  );
}

export const inputClass =
  'h-10 w-full border border-line-strong bg-canvas px-3 text-[14px] text-ink placeholder:text-ink-muted disabled:bg-fog disabled:text-ink-disabled aria-[invalid=true]:border-ember-ink';
